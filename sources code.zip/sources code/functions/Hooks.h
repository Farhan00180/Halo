
#import "functions/autoupdate.h"
#import "variables.h"
#import "functions/ESP/classHexIpa.h"



#pragma GCC diagnostic ignored "-Wunused-function"











// Variables
/*
bool sleepchecks;          // Check if players are sleeping
bool ignoresleep;          // Ignore sleeping players
std::vector<void *> bullets; // Store bullet instances*/
std::vector<void *> players; // Store player instances
//void *local = nullptr;
void *local;     // Local player pointer
//void *Bullet = nullptr;    // Current bullet pointer
void *Bullet;
//bool Silnet = false;       // Silent aim (optional, from second snippet)
float Silnetdist = 100.0f; // Silent aim distance (optional, from second snippet)

// Function Pointers
/*Vector3 (*get_position)(void*);
void (*set_position)(void*, Vector3);
void* (*get_transform)(void*);
void* (*get_camera)();
Vector3 (*WorldToViewpoint)(void*, Vector3);*/

// Helper Functions
float lerps(float a, float b, float t) {
    return a + (b - a) * t;
}

Vector3 world2screen_i(Vector3 pos) { 
	auto cam = HexIpa->camera();    
	if (!cam) return {0,0,0};    

	Vector3 worldPoint = HexIpa->world_to_viewport(cam,pos);   
	Vector3 location; 

	int ScreenWidth = ImGui::GetIO().DisplaySize.x; 
	int ScreenHeight = ImGui::GetIO().DisplaySize.y; 

	location.x = ScreenWidth * worldPoint.x; 
	location.y = ScreenHeight - worldPoint.y * ScreenHeight; 
	location.z = worldPoint.z; 


	return location; 
} 


ImVec2 world2screen_c(Vector3 pos, bool &checker) { 
	auto cam = HexIpa->camera();    
	if (!cam) return {0,0};    
   
	Vector3 worldPoint = HexIpa->world_to_viewport(cam,pos);   
	Vector3 location; 
 
	int ScreenWidth = ImGui::GetIO().DisplaySize.x; 
	int ScreenHeight = ImGui::GetIO().DisplaySize.y; 
 
	location.x = ScreenWidth * worldPoint.x; 
	location.y = ScreenHeight - worldPoint.y * ScreenHeight; 
	location.z = worldPoint.z; 
 
	checker = location.z > 1; 
 
	return {location.x, location.y}; 
}

 Vector3 GetPlayerLocation(void *player) {
  Vector3 location;
  location = HexIpa->position(HexIpa->transform(player));
  return location;
}

int hp(void* a) {
    void* pl_info = *(void**)((uint64_t)a + 0x3F0);
    return *(int*)((uint64_t)pl_info + 0x64);
}

bool sleeppl(void* a) {
    void* pl_info = *(void**)((uint64_t)a + 0x3F0);
    return *(bool*)((uint64_t)pl_info + 0xBA);
}

bool bulletFind(void *thiz) {
    if (thiz) {
        for (auto& bullet : bullets) {
            if (thiz == bullet) {
                return true;
            }
        }
    }
    return false;
}

bool playerFind(void *thiz) {
    if (thiz) {
        for (auto& player : players) {
            if (thiz == player) {
                return true;
            }
        }
    }
    return false;
}

void *getTargetPlayer() {
    int closestEnemyIndex = -1;
    float shortDistance = std::numeric_limits<float>::max();

    for (auto& player : players) {
        if (player) {
            if (hp(player) == 0) {
                continue;
            }
            
            Vector3 player_pos = HexIpa->position(HexIpa->transform(player));
            Vector3 myplayer_pos = HexIpa->position(HexIpa->transform(local));

Vector3 lockPos = HexIpa->world_to_viewport(HexIpa->camera(), *reinterpret_cast<Vector3*>(HexIpa->position));
            
            if (lockPos.z < 1.f) {
                continue;
            }

            float distTo = Vector3::Distance(player_pos, myplayer_pos);
            
            if (distTo <= bulletdist) {
                if (sleepchecks) {
                    if (!sleeppl(player)) {
                        return player;
                    }
                } else {
                    return player;
                }
            }
        }
    }
    return nullptr;
}

// Bullet Hook
//void (*BulletControlFixedUpdateOffset)(void *);
void BulletControl_FixedUpdateOffset(void *thiz) {
    if (thiz) {
        for (auto& bullet : bullets) {
            Bullet = bullet;
        }
        
        if (bulletTrack || Silnet) { // Support both bulletTrack and Silent
            auto targetPlayer = getTargetPlayer();
        
            if (targetPlayer) {
                Vector3 target_pos = HexIpa->position(HexIpa->
transform(targetPlayer));
                
                if (target_pos != Vector3(0.f, 0.f, 0.f)) {
                    HexIpa->set_position(HexIpa->transform(thiz), Vector3(target_pos.x, target_pos.y, target_pos.z));
                }
            }
        }
        
        if (!bulletFind(thiz)) {
            bullets.push_back(thiz);
        }
        
        if (bullets.size() > 50) {
            bullets.clear();
        }
    }
    
    return BulletControl_FixedUpdateOffset(thiz);
}

//void (*BulletControlOnDestroyOffset)(void *);
void BulletControl_OnDestroyOffset(void *thiz) {
    if (thiz) {

BulletControl_OnDestroyOffset(thiz);
    }
    bullets.clear();
}


