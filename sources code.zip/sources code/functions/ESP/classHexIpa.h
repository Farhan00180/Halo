#include <vector>
#include <chrono>
#import "functions/ESP/struct.h"
#define kWidth  [UIScreen mainScreen].bounds.size.width
#define kHeight [UIScreen mainScreen].bounds.size.height

class HexIpa_t{

public:
void init();
Vector3(*position)(void*);
void*(*transform)(void*);
monoArray<uintptr_t>*(*find_objects)(void*);
void*(*get_type)(monoString*);
void*(*camera)();
Vector3(*world_to_viewport)(void*, Vector3);
monoString*(*get_name)(void*);
monoString*(*get_name2)(void*);
void*(*get_PInfo)(void*);
void*(*find_object)(void*);
bool(*isAlive)(void*);
//Bounds(*get_bounds)(void*);
void*(*get_rigidbody)(void*);
void(*set_detectCollisions)(void*, bool);
void(*set_position)(void*, Vector3);
//void(*run)(void*, Vector3);
//void(*rotate_cam)(void*, Vector3);

ImVec2 w2s(Vector3);
ImVec2 w_checker(Vector3, bool&);
};
HexIpa_t* HexIpa = new HexIpa_t();

void HexIpa_t::init(){

this->position = (Vector3 (*)(void*))getRealOffset(GetPositionOffset);
this->transform = (void* (*)(void*))getRealOffset(GetTransformOffset);
this->get_type = (void* (*)(monoString*))getRealOffset(GetTypeOffset);
this->find_objects = (monoArray<uintptr_t>* (*)(void*))getRealOffset(FindObjectsOffset);
this->camera = (void* (*)())getRealOffset(CameraOffset);
this->world_to_viewport = (Vector3 (*)(void*, Vector3))getRealOffset(W2WPOffset);
this->get_name = (monoString* (*)(void*))getRealOffset(GetNameOffset);//0x26F7910
this->get_name2 = (monoString* (*)(void*))getRealOffset(GetName2Offset);
this->get_PInfo = (void *(*)(void*))getRealOffset(GetPlayerInfoOffset);
this->find_object = (void* (*)(void*))getRealOffset(FindObjectOffset);
this->isAlive = (bool (*)(void*))getRealOffset(IsAliveObjectOffset);
//this->get_bounds = (Bounds (*)(void*))getRealOffset(ENC(0x26D30DC));
this->get_rigidbody = (void *(*)(void*))getRealOffset(GetRigidbodyOffset);
this->set_detectCollisions = (void (*)(void*, bool))getRealOffset(SetDetectCollisionsOffset);
this->set_position = (void (*)(void*, Vector3))getRealOffset(SetPositionOffset);
//this->run = (void (*)(void*, Vector3))getRealOffset(ENC(0x102D9D0));
//this->rotate_cam = (void (*)(void*, Vector3))getRealOffset(ENC(0xBF1C70));

}



ImVec2 HexIpa_t::w2s(Vector3 pos) {        
    auto cam = HexIpa->camera();
    if(!cam)return {0,0};
    Vector3 worldPoint = HexIpa->world_to_viewport(cam, pos);
    Vector3 location;
    int ScreenWidth = kWidth;
    int ScreenHeight = kHeight;
    location.x = ScreenWidth * worldPoint.x;
    location.y = ScreenHeight - worldPoint.y * ScreenHeight;
    location.z = worldPoint.z;
    return {location.x, location.y};
}
    
ImVec2 HexIpa_t::w_checker(Vector3 pos, bool &checker) {
    auto cam = HexIpa->camera();
    if(!cam)return {0,0};
    Vector3 worldPoint = HexIpa->world_to_viewport(cam, pos);
    Vector3 location;
    int ScreenWidth = ImGui::GetIO().DisplaySize.x;
    int ScreenHeight = ImGui::GetIO().DisplaySize.y;
    location.x = ScreenWidth * worldPoint.x;
    location.y = ScreenHeight - worldPoint.y * ScreenHeight;
    location.z = worldPoint.z;
    checker = location.z > 1;
    return {location.x, location.y};
}