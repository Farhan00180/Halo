#import "functions/inline-hook/static-inline.h"
#import "variables.h"
#pragma GCC diagnostic ignored "-Wwritable-strings"



static char *UnityFramework = "Frameworks/UnityFramework.framework/UnityFramework";


void offsetFunc(){
            

if(isJb == 0){


if(exbuild){
        if(exbuild_active == NO){
ActiveCodePatch(UnityFramework, ExtendedBuildOffset, "C0035FD6");
            }
        exbuild_active = YES;
    }
    else{
        if(exbuild_active == YES){
DeactiveCodePatch(UnityFramework, ExtendedBuildOffset, "C0035FD6");
            }
        exbuild_active = NO;
    }


if(soul == true){
        if(soul_active == NO){
ActiveCodePatch(UnityFramework, SoulOffset, "C0035FD6");       
            }
        soul_active = YES;
    }
    else{
        if(soul_active == YES){
DeactiveCodePatch(UnityFramework, SoulOffset, "C0035FD6"); 
            }
        soul_active = NO;
    }

if(noshake){
        if(noshake_active == NO){
ActiveCodePatch(UnityFramework, NoShakeOffset, "C0035FD6");       
            }
        noshake_active = YES;
    }
    else{
        if(noshake_active == YES){
DeactiveCodePatch(UnityFramework, NoShakeOffset, "C0035FD6");       
            }
        noshake_active = NO;
    }

if(forcebuild){
        if(forcebuild_active == NO){
ActiveCodePatch(UnityFramework, ForceBuildOffset, "C0035FD6");       
            }
        forcebuild_active = YES;
    }
    else{
        if(forcebuild_active == YES){
DeactiveCodePatch(UnityFramework, ForceBuildOffset, "C0035FD6");       
            }
        forcebuild_active = NO;
    }


if(mtt){
        if(mtt_active == NO){
ActiveCodePatch(UnityFramework, MttOffset1, "C0035FD6");       
ActiveCodePatch(UnityFramework, MttOffset2, "C0035FD6");       
ActiveCodePatch(UnityFramework, MttOffset3, "C0035FD6");       
ActiveCodePatch(UnityFramework, MttOffset4, "C0035FD6");       
ActiveCodePatch(UnityFramework, MttOffset5, "C0035FD6");       
ActiveCodePatch(UnityFramework, MttOffset6, "C0035FD6");       
            }
        mtt_active = YES;
    }
    else{
        if(mtt_active == YES){
DeactiveCodePatch(UnityFramework, MttOffset1, "C0035FD6");       
DeactiveCodePatch(UnityFramework, MttOffset2, "C0035FD6");       
DeactiveCodePatch(UnityFramework, MttOffset3, "C0035FD6");       
DeactiveCodePatch(UnityFramework, MttOffset4, "C0035FD6");       
DeactiveCodePatch(UnityFramework, MttOffset5, "C0035FD6");       
DeactiveCodePatch(UnityFramework, MttOffset6, "C0035FD6");                  
            }
        mtt_active = NO;
    }

if(aimhelpergame){
        if(underwater_active == NO){
ActiveCodePatch(UnityFramework, aimhelpergameOffset, "C0035FD6");       
            }
        aimhelpergame_active = YES;
    }
    else{
        if(aimhelpergame == YES){
DeactiveCodePatch(UnityFramework, aimhelpergameOffset, "C0035FD6");       
            }
        aimhelpergame_active = NO;
    }

    

if(underwater){
        if(underwater_active == NO){
ActiveCodePatch(UnityFramework, UnderWaterOffset, "C0035FD6");       
            }
        underwater_active = YES;
    }
    else{
        if(underwater_active == YES){
DeactiveCodePatch(UnityFramework, UnderWaterOffset, "C0035FD6");       
            }
        underwater_active = NO;
    }

if(nofalldamage){
        if(nofalldamage_active == NO){
ActiveCodePatch(UnityFramework, NoFallDamageOffset1, "C0035FD6");       
ActiveCodePatch(UnityFramework, NoFallDamageOffset2, "C0035FD6");       
ActiveCodePatch(UnityFramework, NoFallDamageOffset3, "C0035FD6");       
            }
        nofalldamage_active = YES;
    }
    else{
        if(nofalldamage_active == YES){
DeactiveCodePatch(UnityFramework, NoFallDamageOffset1, "C0035FD6");       
DeactiveCodePatch(UnityFramework, NoFallDamageOffset2, "C0035FD6");       
DeactiveCodePatch(UnityFramework, NoFallDamageOffset3, "C0035FD6");       
            }
        nofalldamage_active = NO;
    }

if(fakeowner){
        if(fakeowner_active == NO){
ActiveCodePatch(UnityFramework, FakeOwnerOffset1, "200080D2C0035FD6");       
ActiveCodePatch(UnityFramework, FakeOwnerOffset2, "200080D2C0035FD6");       
ActiveCodePatch(UnityFramework, FakeOwnerOffset3, "200080D2C0035FD6");       
ActiveCodePatch(UnityFramework, FakeOwnerOffset4, "200080D2C0035FD6");            
            }
        fakeowner_active = YES;
    }
    else{
        if(fakeowner_active == YES){
DeactiveCodePatch(UnityFramework, FakeOwnerOffset1, "200080D2C0035FD6");       
DeactiveCodePatch(UnityFramework, FakeOwnerOffset2, "200080D2C0035FD6");       
DeactiveCodePatch(UnityFramework, FakeOwnerOffset3, "200080D2C0035FD6");       
DeactiveCodePatch(UnityFramework, FakeOwnerOffset4, "200080D2C0035FD6");                
            }
        fakeowner_active = NO;
    }

if(nospread){
        if(nospread_active == NO){
ActiveCodePatch(UnityFramework, NoSpreadOffset1, "C0035FD6");       
ActiveCodePatch(UnityFramework, NoSpreadOffset2, "C0035FD6");       
            }
        nospread_active = YES;
    }
    else{
        if(nospread_active == YES){
DeactiveCodePatch(UnityFramework, NoSpreadOffset1, "C0035FD6");       
DeactiveCodePatch(UnityFramework, NoSpreadOffset2, "C0035FD6");       
            }
        nospread_active = NO;
    }

if(norecoil){
        if(norecoil_active == NO){
ActiveCodePatch(UnityFramework, NoRecoilOffset, "C0035FD6");       
            }
        norecoil_active = YES;
    }
    else{
        if(norecoil_active == YES){
DeactiveCodePatch(UnityFramework, NoRecoilOffset, "C0035FD6");       
            }
        norecoil_active = NO;
    }

if(picture){
        if(picture_active == NO){
ActiveCodePatch(UnityFramework, PictureOffset, "200080D2C0035FD6");       
            }
        picture_active = YES;
    }
    else{
        if(picture_active == YES){
DeactiveCodePatch(UnityFramework, PictureOffset, "200080D2C0035FD6");       
            }
        picture_active = NO;
    }

if(locktime){
        if(locktime_active == NO){
ActiveCodePatch(UnityFramework, LockTimeOffset, "C0035FD6");       
            }
        locktime_active = YES;
    }
    else{
        if(locktime_active == YES){
DeactiveCodePatch(UnityFramework, LockTimeOffset, "C0035FD6");       
            }
        locktime_active = NO;
    }

if(nograss){
        if(nograss_active == NO){
ActiveCodePatch(UnityFramework, NoGrassOffset, "C0035FD6");       
            }
        nograss_active = YES;
    }
    else{
        if(nograss_active == YES){
DeactiveCodePatch(UnityFramework, NoGrassOffset, "C0035FD6");       
            }
        nograss_active = NO;
    }

if(notree){
        if(notree_active == NO){
ActiveCodePatch(UnityFramework, NoTreeOffset, "C0035FD6");       
            }
        notree_active = YES;
    }
    else{
        if(notree_active == YES){
DeactiveCodePatch(UnityFramework, NoTreeOffset, "C0035FD6");       
            }
        notree_active = NO;
    }



if(name){
        if(name_active == NO){
ActiveCodePatch(UnityFramework, NameOffset, "200080D2C0035FD6");       
            }
        name_active = YES;
    }
    else{
        if(name_active == YES){
DeactiveCodePatch(UnityFramework, NameOffset, "200080D2C0035FD6");       
            }
        name_active = NO;
    }



if(notexture){
    if(notexture_active == NO){
ActiveCodePatch(UnityFramework, NoTextureOffset, "C0035FD6");       
        }
    notexture_active = YES;
}
else{
    if(notexture_active == YES){
DeactiveCodePatch(UnityFramework, NoTextureOffset, "C0035FD6");       
        }
    notexture_active = NO;
}


if(instantexp){
        if(instantexp_active == NO){
ActiveCodePatch(UnityFramework, InstantExpOffset, "C0035FD6");
            }
        instantexp_active = YES;
    }
    else{
        if(instantexp_active == YES){
DeactiveCodePatch(UnityFramework, InstantExpOffset, "C0035FD6");
            }
        instantexp_active = NO;
    }

if(admesp){
        if(admesp_active == NO){
ActiveCodePatch(UnityFramework, AdmEspOffset, "200080D2C0035FD6");
            }
        admesp_active = YES;
    }
    else{
        if(admesp_active == YES){
DeactiveCodePatch(UnityFramework, AdmEspOffset, "200080D2C0035FD6");
            }
        admesp_active = NO;
    }

if(noenemyanim){
        if(noenemyanim_active == NO){
ActiveCodePatch(UnityFramework, NoEnemyAnimOffset1, "C0035FD6");
ActiveCodePatch(UnityFramework, NoEnemyAnimOffset2, "C0035FD6");
            }
        noenemyanim_active = YES;
    }
    else{
        if(noenemyanim_active == YES){
DeactiveCodePatch(UnityFramework, NoEnemyAnimOffset1, "C0035FD6");
DeactiveCodePatch(UnityFramework, NoEnemyAnimOffset2, "C0035FD6");
            }
        noenemyanim_active = NO;
    }


if(traceroff){
        if(traceroff_active == NO){

            }
        traceroff_active = YES;
    }
    else{
        if(traceroff_active == YES){

            }
        traceroff_active = NO;
    }

if(rpgoff){
        if(rpgoff_active == NO){
ActiveCodePatch(UnityFramework, RpgOffOffset, "C0035FD6");
            }
        rpgoff_active = YES;
    }
    else{
        if(rpgoff_active == YES){
DeactiveCodePatch(UnityFramework, RpgOffOffset, "C0035FD6");
            }
        rpgoff_active = NO;
    }

if(drinkwater){
        if(drinkwater_active == NO){
ActiveCodePatch(UnityFramework, DrinkWaterOffset, "C0035FD6");
            }
        drinkwater_active = YES;
    }
    else{
        if(drinkwater_active == YES){
DeactiveCodePatch(UnityFramework, DrinkWaterOffset, "C0035FD6");
            }
        drinkwater_active = NO;
    }

if(gm){

}else{

}


}else{

if(exbuild){
        if(exbuild_active == NO){
            //vm_unity32(ENCRYPTOFFSET("0xEC7810"), strtoul(ENCRYPTHEX("0xC0035FD6"), nullptr, 0));
            //vm_unity32(ENCRYPTOFFSET("0x108AA3C"), strtoul(ENCRYPTHEX("0xC0035FD6"), nullptr, 0));
            vm_unity32(ExtendedBuildOffset, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));

            }
        exbuild_active = YES;
    }
    else{
        if(exbuild_active == YES){
            vm_unity32(ExtendedBuildOffset, strtoul(ENCRYPT("0xFFC302D1"), nullptr, 0));
            }
        exbuild_active = NO;
    }


if(soul){
        if(soul_active == NO){
            
            vm_unity32(SoulOffset, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));

            }
        soul_active = YES;
    }
    else{
        if(soul_active == YES){
            vm_unity32(SoulOffset, strtoul(ENCRYPT("0xFF0303D1"), nullptr, 0));
            }
        soul_active = NO;
    }

if(noshake){
        if(noshake_active == NO){
            vm_unity32(NoShakeOffset, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
            }
        noshake_active = YES;
    }
    else{
        if(noshake_active == YES){
            vm_unity32(NoShakeOffset, strtoul(ENCRYPT("0xED33BB6D"), nullptr, 0));
            }
        noshake_active = NO;
    }

if(forcebuild){
        if(forcebuild_active == NO){
            vm_unity32(ForceBuildOffset, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
            }
        forcebuild_active = YES;
    }
    else{
        if(forcebuild_active == YES){
            vm_unity32(ForceBuildOffset, strtoul(ENCRYPT("0xFF8303D1"), nullptr, 0));
            }
        forcebuild_active = NO;
    }


if(mtt){
        if(mtt_active == NO){
            vm_unity32(MttOffset1, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
            vm_unity32(MttOffset2, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
            vm_unity32(MttOffset3, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
            vm_unity32(MttOffset4, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
            vm_unity32(MttOffset5, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
            vm_unity32(MttOffset6, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
            
            }
        mtt_active = YES;
    }
    else{
        if(mtt_active == YES){
            vm_unity32(MttOffset1, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
            vm_unity32(MttOffset2, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
            vm_unity32(MttOffset3, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
            vm_unity32(MttOffset4, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
            vm_unity32(MttOffset5, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
            vm_unity32(MttOffset1, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
            
            }
        mtt_active = NO;
    }

if(underwater){
        if(underwater_active == NO){
            vm_unity32(UnderWaterOffset, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
            }
        underwater_active = YES;
    }
    else{
        if(underwater_active == YES){
            vm_unity32(UnderWaterOffset, strtoul(ENCRYPT("0xED33B96D"), nullptr, 0));
            }
        underwater_active = NO;
    }

if(nofalldamage){
        if(nofalldamage_active == NO){
            vm_unity32(NoFallDamageOffset1, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
            vm_unity32(NoFallDamageOffset2, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
            vm_unity32(NoFallDamageOffset3, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
            }
        nofalldamage_active = YES;
    }
    else{
        if(nofalldamage_active == YES){
            vm_unity32(NoFallDamageOffset1, strtoul(ENCRYPT("0xE923BD6D"), nullptr, 0));
            vm_unity32(NoFallDamageOffset2, strtoul(ENCRYPT("0xF44FBEA9"), nullptr, 0));
            vm_unity32(NoFallDamageOffset3, strtoul(ENCRYPT("0xF85FBCA9"), nullptr, 0));
            }
        nofalldamage_active = NO;
    }

if(fakeowner){
        if(fakeowner_active == NO){
            vm_unity(FakeOwnerOffset1, strtoul(ENCRYPT("0x200080D2C0035FD6"), nullptr, 0));
            vm_unity(FakeOwnerOffset2, strtoul(ENCRYPT("0x200080D2C0035FD6"), nullptr, 0));
            vm_unity(FakeOwnerOffset3, strtoul(ENCRYPT("0x200080D2C0035FD6"), nullptr, 0));
            vm_unity(FakeOwnerOffset4, strtoul(ENCRYPT("0x200080D2C0035FD6"), nullptr, 0));
            }
        fakeowner_active = YES;
    }
    else{
        if(fakeowner_active == YES){
            vm_unity(FakeOwnerOffset1, strtoul(ENCRYPT("0x200080D2C0035FD6"), nullptr, 0));
            vm_unity(FakeOwnerOffset2, strtoul(ENCRYPT("0x200080D2C0035FD6"), nullptr, 0));
            vm_unity(FakeOwnerOffset3, strtoul(ENCRYPT("0x200080D2C0035FD6"), nullptr, 0));
            vm_unity(FakeOwnerOffset4, strtoul(ENCRYPT("0x200080D2C0035FD6"), nullptr, 0));
            }
        fakeowner_active = NO;
    }

if(nospread){
        if(nospread_active == NO){
            vm_unity32(NoSpreadOffset1, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
            vm_unity32(NoSpreadOffset2, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
            }
        nospread_active = YES;
    }
    else{
        if(nospread_active == YES){
            vm_unity32(NoSpreadOffset1, strtoul(ENCRYPT("0xEB2BBC6D"), nullptr, 0));
            vm_unity32(NoSpreadOffset2, strtoul(ENCRYPT("0xEB2BBC6D"), nullptr, 0));
            }
        nospread_active = NO;
    }

if(norecoil){
        if(norecoil_active == NO){
            vm_unity32(NoRecoilOffset, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
            }
        norecoil_active = YES;
    }
    else{
        if(norecoil_active == YES){
            vm_unity32(NoRecoilOffset, strtoul(ENCRYPT("0xEB2BBC6D"), nullptr, 0));
            }
        norecoil_active = NO;
    }

if(picture){
        if(picture_active == NO){
            vm_unity(PictureOffset, strtoul(ENCRYPT("0x200080D2C0035FD6"), nullptr, 0));
            }
        picture_active = YES;
    }
    else{
        if(picture_active == YES){
            vm_unity(PictureOffset, strtoul(ENCRYPT("0xF44FBEA9FD7B01A9"), nullptr, 0));
            }
        picture_active = NO;
    }

if(locktime){
        if(locktime_active == NO){
            vm_unity32(LockTimeOffset, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
            }
        locktime_active = YES;
    }
    else{
        if(locktime_active == YES){
            vm_unity32(LockTimeOffset, strtoul(ENCRYPT("0xF44FBEA9"), nullptr, 0));
            }
        locktime_active = NO;
    }

if(nograss){
        if(nograss_active == NO){
            vm_unity32(NoGrassOffset, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
            }
        nograss_active = YES;
    }
    else{
        if(nograss_active == YES){
            vm_unity32(NoGrassOffset, strtoul(ENCRYPT("0xF85FBCA9"), nullptr, 0));
            }
        nograss_active = NO;
    }

if(notree){
        if(notree_active == NO){
            vm_unity32(NoTreeOffset, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
            }
        notree_active = YES;
    }
    else{
        if(notree_active == YES){
            vm_unity32(NoTreeOffset, strtoul(ENCRYPT("0xF657BDA9"), nullptr, 0));
            }
        notree_active = NO;
    }



if(name){
        if(name_active == NO){
            vm_unity(NameOffset, strtoul(ENCRYPT("0x200080D2C0035FD6"), nullptr, 0));
            //vm_unity(ENCRYPTOFFSET("0x1167794"), strtoul(ENCRYPTHEX("0x200080D2C0035FD6"), nullptr, 0));
            }
        name_active = YES;
    }
    else{
        if(name_active == YES){
            vm_unity(NameOffset, strtoul(ENCRYPT("0x200080D2C0035FD6"), nullptr, 0));
            //vm_unity(ENCRYPTOFFSET("0x1167794"), strtoul(ENCRYPTHEX("0xF657BDA9F44F01A9"), nullptr, 0));
            }
        name_active = NO;
    }



    if(notexture){
        if(notexture_active == NO){
            vm_unity32(NoTextureOffset, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
            }
        notexture_active = YES;
    }
    else{
        if(notexture_active == YES){
            vm_unity32(NoTextureOffset, strtoul(ENCRYPT("0xF657BDA9"), nullptr, 0));
            }
        notexture_active = NO;
    }

if(bypass){
if(bypass_active == NO){	

vm_unity32(BpOff1, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff2, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff3, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff4, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff5, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff6, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff7, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));

vm_unity32(BpOff8, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff9, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff10, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff11, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff12, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff13, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff14, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));

vm_unity32(BpOff15, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff16, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff17, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff18, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff19, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity(BpOff20, strtoul(ENCRYPT("0x200080D2C0035FD6"), nullptr, 0)); 
vm_unity(BpOff21, strtoul(ENCRYPT("0x200080D2C0035FD6"), nullptr, 0)); 

vm_unity(BpOff22, strtoul(ENCRYPT("0x200080D2C0035FD6"), nullptr, 0)); 
vm_unity32(BpOff23, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff24, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff27, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff26, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff28, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff29, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff30, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff31, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff32, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff33, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff34, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff35, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff36, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff37, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff37, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff38, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff39, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff40, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff41, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff42, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff43, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff44, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff45, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff46, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff47, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff48, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff49, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff50, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff51, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));

/*vm_unity32(ENCRYPTOFFSET("0xE95A14"), strtoul(ENCRYPTHEX("0xC0035FD6"), nullptr, 0));
vm_unity32(ENCRYPTOFFSET("0xE95AE0"), strtoul(ENCRYPTHEX("0xC0035FD6"), nullptr, 0));
vm_unity32(ENCRYPTOFFSET("0xE95C68"), strtoul(ENCRYPTHEX("0xC0035FD6"), nullptr, 0));
vm_unity32(ENCRYPTOFFSET("0xE95CC0"), strtoul(ENCRYPTHEX("0xC0035FD6"), nullptr, 0));
vm_unity32(ENCRYPTOFFSET("0xE96E68"), strtoul(ENCRYPTHEX("0xC0035FD6"), nullptr, 0));
vm_unity32(ENCRYPTOFFSET("0xE96F14"), strtoul(ENCRYPTHEX("0xC0035FD6"), nullptr, 0));
vm_unity32(ENCRYPTOFFSET("0xE9718C"), strtoul(ENCRYPTHEX("0xC0035FD6"), nullptr, 0));
vm_unity32(ENCRYPTOFFSET("0xE96C88"), strtoul(ENCRYPTHEX("0xC0035FD6"), nullptr, 0));
vm_unity32(ENCRYPTOFFSET("0xE96D28"), strtoul(ENCRYPTHEX("0xC0035FD6"), nullptr, 0));
vm_unity32(ENCRYPTOFFSET("0xE96DC8"), strtoul(ENCRYPTHEX("0xC0035FD6"), nullptr, 0));
vm_unity32(ENCRYPTOFFSET("0xE9729C"), strtoul(ENCRYPTHEX("0xC0035FD6"), nullptr, 0));
vm_unity32(ENCRYPTOFFSET("0xE96BE8"), strtoul(ENCRYPTHEX("0xC0035FD6"), nullptr, 0));
vm_unity32(ENCRYPTOFFSET("0xE97D18"), strtoul(ENCRYPTHEX("0xC0035FD6"), nullptr, 0));
vm_unity32(ENCRYPTOFFSET("0xE9846C"), strtoul(ENCRYPTHEX("0xC0035FD6"), nullptr, 0));
vm_unity32(ENCRYPTOFFSET("0xE984C0"), strtoul(ENCRYPTHEX("0xC0035FD6"), nullptr, 0));
vm_unity32(ENCRYPTOFFSET("0xE985CC"), strtoul(ENCRYPTHEX("0xC0035FD6"), nullptr, 0));
vm_unity32(ENCRYPTOFFSET("0xE98068"), strtoul(ENCRYPTHEX("0xC0035FD6"), nullptr, 0));
vm_unity32(ENCRYPTOFFSET("0xE98A64"), strtoul(ENCRYPTHEX("0xC0035FD6"), nullptr, 0));
vm_unity32(ENCRYPTOFFSET("0xE98FD0"), strtoul(ENCRYPTHEX("0xC0035FD6"), nullptr, 0));
vm_unity32(ENCRYPTOFFSET("0xE99234"), strtoul(ENCRYPTHEX("0xC0035FD6"), nullptr, 0));
vm_unity32(ENCRYPTOFFSET("0xE97C1C"), strtoul(ENCRYPTHEX("0xC0035FD6"), nullptr, 0));
vm_unity32(ENCRYPTOFFSET("0xE9960C"), strtoul(ENCRYPTHEX("0xC0035FD6"), nullptr, 0));
vm_unity32(ENCRYPTOFFSET("0xE9967C"), strtoul(ENCRYPTHEX("0xC0035FD6"), nullptr, 0));
vm_unity32(ENCRYPTOFFSET("0xE996EC"), strtoul(ENCRYPTHEX("0xC0035FD6"), nullptr, 0));
vm_unity32(ENCRYPTOFFSET("0xE99780"), strtoul(ENCRYPTHEX("0xC0035FD6"), nullptr, 0));
vm_unity32(ENCRYPTOFFSET("0xE8CF9C"), strtoul(ENCRYPTHEX("0xC0035FD6"), nullptr, 0));*/

vm_unity32(BpOff52, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff53, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff54, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff55, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff56, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff57, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff58, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff59, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff60, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff61, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff62, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff63, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));

vm_unity32(BpOff64, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff65, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff66, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff67, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff68, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff69, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff70, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));

vm_unity32(BpOff71, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff72, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff73, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff74, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff75, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff76, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff77, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));

vm_unity32(BpOff78, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff79, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff80, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff81, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff82, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff83, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff84, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));

vm_unity32(BpOff85, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));

vm_unity32(BpOff86, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff87, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff88, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));

vm_unity32(BpOff89, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff90, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));

vm_unity32(BpOff91, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff92, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff93, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));

vm_unity32(BpOff94, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));

vm_unity32(BpOff95, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));

vm_unity32(BpOff96, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));

vm_unity32(BpOff97, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));

vm_unity32(BpOff98, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));

vm_unity32(BpOff99, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));

vm_unity32(BpOff100, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));

vm_unity32(BpOff101, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));

vm_unity32(BpOff102, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));

vm_unity32(BpOff103, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));

vm_unity32(BpOff104, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));

vm_unity32(BpOff105, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));

vm_unity32(BpOff106, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));

vm_unity32(BpOff107, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));

vm_unity32(BpOff108, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));

vm_unity32(BpOff109, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));

vm_unity32(BpOff110, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));

vm_unity32(BpOff111, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));

vm_unity32(BpOff112, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));

vm_unity32(BpOff113, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));

vm_unity32(BpOff114, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff115, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff116, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff117, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff118, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff119, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff120, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff121, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff122, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff123, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff124, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff125, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff126, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff127, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff128, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff129, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff130, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff131, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff132, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff133, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff134, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff135, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff136, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff137, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff138, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff139, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff140, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff141, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff142, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff143, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff144, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff145, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff146, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff147, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff148, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff149, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff150, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff151, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff152, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff153, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff154, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff155, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff156, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff157, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff158, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff159, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff160, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff161, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff162, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff163, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff164, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff165, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff166, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff167, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff168, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff169, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff170, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff171, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff172, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff173, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff174, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff175, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff176, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff177, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff178, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff179, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff180, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff181, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff182, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff183, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff184, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff185, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff186, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff187, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff188, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff189, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff190, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff191, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff192, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff193, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff194, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff195, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff196, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff197, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff198, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff199, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff200, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff201, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff202, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff203, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff204, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff205, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff206, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff207, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff208, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff209, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff210, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff211, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff212, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff213, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff214, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff215, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff216, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff217, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff218, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff219, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff220, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff221, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff222, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff223, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff224, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff225, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff226, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff227, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff228, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff229, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff230, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff231, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff232, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff233, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff234, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff235, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff236, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff237, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff238, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff239, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff240, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff241, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff242, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff243, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff244, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff245, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff246, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff247, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff248, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff249, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff250, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff251, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff252, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff253, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff254, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff255, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff256, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff257, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff258, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff259, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff260, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff261, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff262, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff263, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff264, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff265, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff266, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff267, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff268, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff269, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff270, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff271, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff272, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff273, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff274, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff275, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff276, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff277, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff278, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff279, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff280, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff281, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff282, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff283, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff284, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff285, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff286, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff287, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff288, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff289, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff290, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff291, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff292, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff293, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff294, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff295, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff296, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff297, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff298, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff299, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff300, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff301, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff302, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff303, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff304, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff305, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff306, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff307, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff308, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff309, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff310, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff311, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff312, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff313, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff314, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff315, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff316, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff317, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff318, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff319, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff320, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff321, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff322, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff323, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff324, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff325, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff326, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff327, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff328, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff329, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff330, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff331, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff332, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff333, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff334, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff335, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff336, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff337, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff338, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff339, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff340, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff341, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff342, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff343, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff344, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff345, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff346, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff347, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff348, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff349, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff350, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff351, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff352, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff353, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff354, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff355, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff356, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff357, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff358, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff359, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff360, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff361, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff362, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff363, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff364, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff365, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff366, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff367, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff368, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff369, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff370, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff371, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff372, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff373, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff374, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff375, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff376, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff377, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff378, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff379, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff380, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff381, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff382, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff383, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff384, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff385, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff386, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff387, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff388, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff389, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff390, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff391, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff392, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff393, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff394, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff395, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff396, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff397, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff398, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff399, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff400, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff401, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff402, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff403, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff404, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff405, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff406, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff407, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff408, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff409, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff410, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff411, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff412, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff413, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff414, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff415, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff416, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff417, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff418, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff419, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff420, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff421, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff422, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff423, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff424, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff425, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff426, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff427, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff428, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff429, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff430, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff431, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff432, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff433, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff434, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff435, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff436, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff437, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff438, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff439, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff440, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff441, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff442, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff443, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff444, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff445, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff446, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff447, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff448, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff449, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff450, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff451, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff452, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff453, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff454, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff455, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff456, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff457, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff458, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff459, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff460, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff461, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff462, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff463, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff464, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff465, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff466, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff467, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff468, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff469, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff470, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff471, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff472, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff473, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff474, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff475, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff476, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff477, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff478, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff479, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff480, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff481, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff482, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff483, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff484, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff485, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff486, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff487, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff488, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff489, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff490, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff491, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff492, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff493, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff494, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff495, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff496, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff497, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff498, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff499, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff500, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff501, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff502, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff503, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff504, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff505, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff506, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff507, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff508, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff509, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff510, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff511, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff512, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff513, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff514, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff515, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff516, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff517, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff518, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff519, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff520, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff521, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff522, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff523, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff524, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff525, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff526, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff527, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff528, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff529, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff530, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff531, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff532, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff533, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff534, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff535, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff536, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff537, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff538, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff539, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff540, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff541, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff542, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff543, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff544, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff545, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff546, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff547, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff548, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff549, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff550, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff551, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff552, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff553, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff554, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff555, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff556, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff557, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff558, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff559, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff560, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff561, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff562, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff563, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff564, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff565, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff566, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff567, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff568, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff569, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff570, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff571, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff572, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff573, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff574, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff575, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff576, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff577, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff578, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff579, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff580, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff581, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff582, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff583, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff584, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff585, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff586, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff587, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff588, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff589, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff590, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff591, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff592, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff593, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff594, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff595, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff596, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff597, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff598, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff599, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff600, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff601, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff602, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff603, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff604, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff605, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff606, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff607, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff608, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff609, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff610, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff611, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff612, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff613, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff614, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff615, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff616, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff617, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff618, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff619, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff620, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff621, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff622, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff623, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff624, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff625, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff626, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff627, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff628, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff629, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff630, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff631, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff632, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff633, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff634, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff635, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff636, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff637, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff638, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff639, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff640, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff641, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff642, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff643, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff644, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff645, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff646, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff647, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff648, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff649, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff650, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff651, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff652, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff653, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff654, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff655, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff656, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff657, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff658, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff659, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff660, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff661, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));

vm_unity32(BpOff700, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff701, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff702, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff703, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff704, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff705, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff706, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff707, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff708, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff709, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff710, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff711, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff712, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff713, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff714, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff715, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff716, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff717, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff718, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff719, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff720, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff721, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff722, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff723, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff724, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff725, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff726, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff727, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff728, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff729, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff730, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff731, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff732, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff733, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff734, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff735, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff736, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff737, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff738, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff739, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff740, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff741, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff742, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff743, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff744, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff745, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff746, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff747, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff748, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff749, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff750, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff751, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff752, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff753, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff754, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff755, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff756, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff757, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff758, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff759, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff760, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff761, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff762, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff763, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff764, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff765, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff766, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff767, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff768, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff769, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff770, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff771, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff772, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff773, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff774, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff775, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff776, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff777, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff778, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff779, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff780, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff781, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff782, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff783, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff784, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff785, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff786, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff787, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff801, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff802, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff803, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff804, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff805, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff806, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff807, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff808, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff809, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff810, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff811, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff812, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff813, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff814, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff815, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff816, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff817, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff818, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff819, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff820, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff821, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff822, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff823, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff824, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff825, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff826, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff827, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff828, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff829, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff830, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff831, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff832, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff833, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff834, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff835, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff836, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff837, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff838, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff839, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff840, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff841, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff842, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff843, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff844, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff845, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff846, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff847, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff848, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff849, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff850, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff851, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff852, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff853, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff854, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff855, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff856, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff857, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff858, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff859, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff860, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff861, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff862, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff863, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff864, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff865, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff866, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff867, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff868, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff869, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff870, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff871, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff872, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff873, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff874, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff875, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff876, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff877, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff878, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff879, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff880, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff881, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff882, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff883, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff884, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff885, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff886, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff887, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff888, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff889, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff890, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff891, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff892, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff893, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff894, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff895, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff896, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff897, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff898, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff899, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff900, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff901, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff902, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff903, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff904, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff905, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff906, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff907, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff908, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff909, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff910, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff911, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff912, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff913, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff914, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff915, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff916, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff917, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff918, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff919, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff920, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff921, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff922, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff923, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff924, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff925, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff926, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff927, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff928, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff929, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff930, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff931, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff932, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff933, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff934, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff935, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff936, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff937, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff938, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff939, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff940, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff941, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff942, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff943, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff944, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff945, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff946, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff947, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff948, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff949, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff950, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff951, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff952, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff953, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff954, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff955, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff956, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff957, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff958, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff959, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff960, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff961, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff962, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff963, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff964, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff965, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff966, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff967, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff968, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff969, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff970, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff971, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff972, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff973, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff974, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff975, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff976, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff977, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff978, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff979, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff980, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff981, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff982, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff983, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff984, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff985, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff986, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff987, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff988, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff989, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff990, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff991, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff992, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff993, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff994, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff995, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff996, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff997, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff998, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff999, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1000, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1001, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1002, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1003, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1004, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1005, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1006, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1007, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1008, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1009, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1010, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1011, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1012, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1013, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1014, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1015, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1016, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1017, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1018, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1019, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1020, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1021, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1022, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1023, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1024, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1025, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1026, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1027, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1028, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1029, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1030, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1031, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1032, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1033, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1034, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1035, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1036, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1037, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1038, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1039, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1040, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1041, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1042, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1043, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1044, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1045, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1046, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1047, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1048, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1049, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1050, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1051, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1052, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1053, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1054, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1055, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1056, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1057, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1058, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1059, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1060, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1061, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1062, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1063, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1064, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1065, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1066, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1067, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1068, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1069, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1070, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1071, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1072, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1073, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1074, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1075, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1076, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1077, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1078, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1079, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1080, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1081, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1082, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1083, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1084, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1085, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1086, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1087, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1088, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1089, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1090, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1091, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1092, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1093, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1094, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1095, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1096, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1097, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1098, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1099, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1100, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1101, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1102, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1103, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1104, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1105, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1106, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1107, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1108, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1109, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1110, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1111, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1112, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1113, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1114, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1115, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1116, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1117, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1118, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1119, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1120, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1121, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1122, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1123, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1124, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1125, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1126, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1127, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1128, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1129, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1130, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1131, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1132, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1133, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1134, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1135, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1136, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1137, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1138, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1139, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1140, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1141, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1142, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1143, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1144, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1145, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1146, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1147, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1148, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1149, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1150, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1151, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1152, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1153, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1154, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1155, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1156, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1157, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1158, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1159, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1160, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1161, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1162, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1163, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1164, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1165, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1166, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1167, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1168, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1169, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1170, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1171, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1172, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1173, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1174, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1175, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1176, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1177, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1178, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1179, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1180, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1181, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1182, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1183, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1184, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1185, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1186, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1187, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1188, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1189, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1190, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1191, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1192, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1193, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1194, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1195, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1196, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1197, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1198, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1199, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1200, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1201, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1202, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1203, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1204, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1205, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1206, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1207, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1208, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1209, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1210, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1211, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1212, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1213, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1214, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1215, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1216, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1217, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1218, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1219, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1220, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1221, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1222, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1223, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1224, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1225, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1226, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1227, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1228, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1229, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1230, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1231, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1232, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1233, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1234, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1235, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1236, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1237, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1238, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1239, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1240, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1241, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1242, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1243, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1244, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1245, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1246, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1247, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1248, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1249, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1250, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1251, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1252, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1253, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1254, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1255, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1256, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1257, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1258, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1259, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1260, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1261, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1262, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1263, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1264, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1265, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1266, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1267, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1268, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1269, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1270, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1271, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1272, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1273, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1274, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1275, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1276, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1277, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1278, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1279, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1280, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1281, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1282, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1283, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1284, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1285, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1286, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1287, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1288, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1289, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1290, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1291, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1292, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1293, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1294, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1295, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1296, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1297, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1298, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1299, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1300, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1301, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1302, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1303, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1304, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1305, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1306, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1307, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1308, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1309, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1310, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1311, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1312, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1313, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1314, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1315, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1316, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1317, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1318, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1319, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1320, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1321, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1322, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1323, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1324, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1325, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1326, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1327, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1328, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1329, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1330, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1331, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1332, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1333, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1334, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1335, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1336, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1337, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1338, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1339, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1340, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1341, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0)); 
vm_unity32(BpOff1342, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1343, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1344, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1345, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1346, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1347, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1348, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1349, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1350, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1351, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1352, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1353, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1354, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1355, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1356, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1357, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1358, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1359, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1360, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1361, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1362, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1363, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1364, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1365, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1366, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1367, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1368, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
vm_unity32(BpOff1369, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
// Namespace: 
// WarChoiceMgr methods
vm_unity32(BpOff1369, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0)); // get_CurRegionId
vm_unity32(BpOff1370, strtoul(ENCRYPT("0xC00360D6"), nullptr, 0)); // set_CurRegionId
vm_unity32(BpOff1371, strtoul(ENCRYPT("0xC00361D6"), nullptr, 0)); // get_IsLobbyLookModel
vm_unity32(BpOff1372, strtoul(ENCRYPT("0xC00362D6"), nullptr, 0)); // set_IsLobbyLookModel
vm_unity32(BpOff1373, strtoul(ENCRYPT("0xC00363D6"), nullptr, 0)); // get_IsLookModel
vm_unity32(BpOff1374, strtoul(ENCRYPT("0xC00364D6"), nullptr, 0)); // set_IsLookModel
vm_unity32(BpOff1375, strtoul(ENCRYPT("0xC00365D6"), nullptr, 0)); // Init
vm_unity32(BpOff1376, strtoul(ENCRYPT("0xC00366D6"), nullptr, 0)); // OnBattleClear
vm_unity32(BpOff1377, strtoul(ENCRYPT("0xC00367D6"), nullptr, 0)); // OnSCustomCreateRoleItem
vm_unity32(BpOff1378, strtoul(ENCRYPT("0xC00368D6"), nullptr, 0)); // OnSGetCreateRoleItem
vm_unity32(BpOff1379, strtoul(ENCRYPT("0xC00369D6"), nullptr, 0)); // SendGetCreateRoleItem
vm_unity32(BpOff1380, strtoul(ENCRYPT("0xC0036AD6"), nullptr, 0)); // Clear
vm_unity32(BpOff1381, strtoul(ENCRYPT("0xC0036BD6"), nullptr, 0)); // OnZhanjuEnd
vm_unity32(BpOff1382, strtoul(ENCRYPT("0xC0036CD6"), nullptr, 0)); // OnGetBsInfo
vm_unity32(BpOff1383, strtoul(ENCRYPT("0xC0036DD6"), nullptr, 0)); // OnGetOtherBsInfo
vm_unity32(BpOff1384, strtoul(ENCRYPT("0xC0036ED6"), nullptr, 0)); // OnSSearchZhanju
vm_unity32(BpOff1385, strtoul(ENCRYPT("0xC0036FD6"), nullptr, 0)); // set_SGetZhanJuLastOpenTime
vm_unity32(BpOff1386, strtoul(ENCRYPT("0xC00370D6"), nullptr, 0)); // get_SGetZhanJuLastOpenTime
vm_unity32(BpOff1387, strtoul(ENCRYPT("0xC00371D6"), nullptr, 0)); // OnSGetZhanJuLastOpenTime
vm_unity32(BpOff1388, strtoul(ENCRYPT("0xC00372D6"), nullptr, 0)); // SendCGetZhanJuLastOpenTime
vm_unity32(BpOff1389, strtoul(ENCRYPT("0xC00373D6"), nullptr, 0)); // OnSGetLastZhanjuOpenTime
vm_unity32(BpOff1390, strtoul(ENCRYPT("0xC00374D6"), nullptr, 0)); // SendCGetLastZhanjuOpenTime
vm_unity32(BpOff1391, strtoul(ENCRYPT("0xC00375D6"), nullptr, 0)); // OnSReginServersForPing
vm_unity32(BpOff1392, strtoul(ENCRYPT("0xC00376D6"), nullptr, 0)); // GetNewbiePing
vm_unity32(BpOff1393, strtoul(ENCRYPT("0xC00377D6"), nullptr, 0)); // OnSZhanjuResult
vm_unity32(BpOff1394, strtoul(ENCRYPT("0xC00378D6"), nullptr, 0)); // OnSDefaultBs
vm_unity32(BpOff1395, strtoul(ENCRYPT("0xC00379D6"), nullptr, 0)); // GetPings
vm_unity32(BpOff1396, strtoul(ENCRYPT("0xC0037AD6"), nullptr, 0)); // StopPing
vm_unity32(BpOff1397, strtoul(ENCRYPT("0xC0037BD6"), nullptr, 0)); // CheckPing
vm_unity32(BpOff1398, strtoul(ENCRYPT("0xC0037CD6"), nullptr, 0)); // SendGetDefaultBs
vm_unity32(BpOff1399, strtoul(ENCRYPT("0xC0037DD6"), nullptr, 0)); // IsShouHuModel
vm_unity32(BpOff1400, strtoul(ENCRYPT("0xC0037ED6"), nullptr, 0)); // IsCanEnterNormalRegion
vm_unity32(BpOff1401, strtoul(ENCRYPT("0xC0037FD6"), nullptr, 0)); // IsCanEnterAntiCheatRegion
vm_unity32(BpOff1402, strtoul(ENCRYPT("0xC00380D6"), nullptr, 0)); // isCompetitionRegion
vm_unity32(BpOff1403, strtoul(ENCRYPT("0xC00381D6"), nullptr, 0)); // SetDefault
vm_unity32(BpOff1404, strtoul(ENCRYPT("0xC00382D6"), nullptr, 0)); // GetMapPathsById
vm_unity32(BpOff1405, strtoul(ENCRYPT("0xC00383D6"), nullptr, 0)); // GetOfficialBasePathList
vm_unity32(BpOff1406, strtoul(ENCRYPT("0xC00384D6"), nullptr, 0)); // GetPingWithRegionId
vm_unity32(BpOff1407, strtoul(ENCRYPT("0xC00385D6"), nullptr, 0)); // GetBattleDay
vm_unity32(BpOff1408, strtoul(ENCRYPT("0xC00386D6"), nullptr, 0)); // SendCWantEnterBs
vm_unity32(BpOff1409, strtoul(ENCRYPT("0xC00387D6"), nullptr, 0)); // .ctor

// Namespace: SC.UI
// BattleMapShouHuoJi methods
vm_unity32(BpOff1410, strtoul(ENCRYPT("0xC00388D6"), nullptr, 0)); // OnInit
vm_unity32(BpOff1411, strtoul(ENCRYPT("0xC00389D6"), nullptr, 0)); // OnShow
vm_unity32(BpOff1412, strtoul(ENCRYPT("0xC0038AD6"), nullptr, 0)); // UpdateFixedIndex
vm_unity32(BpOff1413, strtoul(ENCRYPT("0xC0038BD6"), nullptr, 0)); // MoveForward
vm_unity32(BpOff1414, strtoul(ENCRYPT("0xC0038CD6"), nullptr, 0)); // Hide
vm_unity32(BpOff1415, strtoul(ENCRYPT("0xC0038DD6"), nullptr, 0)); // Update
vm_unity32(BpOff1416, strtoul(ENCRYPT("0xC0038ED6"), nullptr, 0)); // SetName
vm_unity32(BpOff1417, strtoul(ENCRYPT("0xC0038FD6"), nullptr, 0)); // GetNextTimeRefresh
vm_unity32(BpOff1418, strtoul(ENCRYPT("0xC00390D6"), nullptr, 0)); // RefreshAllInfo
vm_unity32(BpOff1419, strtoul(ENCRYPT("0xC00391D6"), nullptr, 0)); // UpdateScrollPanel
vm_unity32(BpOff1420, strtoul(ENCRYPT("0xC00392D6"), nullptr, 0)); // FillShouHuoJiCell
vm_unity32(BpOff1421, strtoul(ENCRYPT("0xC00393D6"), nullptr, 0)); // GetOneCost

// Namespace: 
// PlayerController methods
vm_unity32(BpOff1422, strtoul(ENCRYPT("0xC00394D6"), nullptr, 0)); // get_IsJiMiao
vm_unity32(BpOff1423, strtoul(ENCRYPT("0xC00395D6"), nullptr, 0)); // get_IsNewJiMiao
vm_unity32(BpOff1424, strtoul(ENCRYPT("0xC00396D6"), nullptr, 0)); // get_IsJiMiaoHavejing
vm_unity32(BpOff1425, strtoul(ENCRYPT("0xC00397D6"), nullptr, 0)); // get_CanOpenJimiao
vm_unity32(BpOff1426, strtoul(ENCRYPT("0xC00398D6"), nullptr, 0)); // set_CanOpenJimiao
vm_unity32(BpOff1427, strtoul(ENCRYPT("0xC00399D6"), nullptr, 0)); // get_IsWuRenJi
vm_unity32(BpOff1428, strtoul(ENCRYPT("0xC0039AD6"), nullptr, 0)); // SendHideTuzhiMsgIfHave
vm_unity32(BpOff1429, strtoul(ENCRYPT("0xC0039BD6"), nullptr, 0)); // CheckCanMoveUp
vm_unity32(BpOff1430, strtoul(ENCRYPT("0xC0039CD6"), nullptr, 0)); // CheckCanOpenJimiao
vm_unity32(BpOff1431, strtoul(ENCRYPT("0xC0039DD6"), nullptr, 0)); // CheckNearLowToTopTiZi
vm_unity32(BpOff1432, strtoul(ENCRYPT("0xC0039ED6"), nullptr, 0)); // CheckNearTopToLowTiZi
vm_unity32(BpOff1433, strtoul(ENCRYPT("0xC0039FD6"), nullptr, 0)); // CheckTianXian
vm_unity32(BpOff1434, strtoul(ENCRYPT("0xC003A0D6"), nullptr, 0)); // IsThrouthLajidui
vm_unity32(BpOff1435, strtoul(ENCRYPT("0xC003A1D6"), nullptr, 0)); // IsThrouthHuoLun
vm_unity32(BpOff1436, strtoul(ENCRYPT("0xC003A2D6"), nullptr, 0)); // IsThrouthMine
vm_unity32(BpOff1437, strtoul(ENCRYPT("0xC003A3D6"), nullptr, 0)); // CheckGetOutBoat
vm_unity32(BpOff1438, strtoul(ENCRYPT("0xC003A4D6"), nullptr, 0)); // IsThroughWallByDoAction
vm_unity32(BpOff1439, strtoul(ENCRYPT("0xC003A5D6"), nullptr, 0)); // get_InQiuQian
vm_unity32(BpOff1440, strtoul(ENCRYPT("0xC003A6D6"), nullptr, 0)); // set_InQiuQian
vm_unity32(BpOff1441, strtoul(ENCRYPT("0xC003A7D6"), nullptr, 0)); // OnGetInQiuQian
vm_unity32(BpOff1442, strtoul(ENCRYPT("0xC003A8D6"), nullptr, 0)); // OnGetOutQiuQian
vm_unity32(BpOff1443, strtoul(ENCRYPT("0xC003A9D6"), nullptr, 0)); // InitWrjCameraTarget
vm_unity32(BpOff1444, strtoul(ENCRYPT("0xC003AAD6"), nullptr, 0)); // CheckCanUseInterferenceItem

// Namespace: SC.UI
// BattleZhanLiPanel methods
vm_unity32(BpOff1445, strtoul(ENCRYPT("0xC003ABD6"), nullptr, 0)); // onInit
vm_unity32(BpOff1446, strtoul(ENCRYPT("0xC003ACD6"), nullptr, 0)); // onShow
vm_unity32(BpOff1447, strtoul(ENCRYPT("0xC003ADD6"), nullptr, 0)); // onHide
vm_unity32(BpOff1448, strtoul(ENCRYPT("0xC003AED6"), nullptr, 0)); // onDestroy
vm_unity32(BpOff1449, strtoul(ENCRYPT("0xC003AFD6"), nullptr, 0)); // OnZhanLiChange
vm_unity32(BpOff1450, strtoul(ENCRYPT("0xC003B0D6"), nullptr, 0)); // ShowNum
vm_unity32(BpOff1451, strtoul(ENCRYPT("0xC003B1D6"), nullptr, 0)); // PlayAnimation
vm_unity32(BpOff1452, strtoul(ENCRYPT("0xC003B2D6"), nullptr, 0)); // NumChange
vm_unity32(BpOff1453, strtoul(ENCRYPT("0xC003B3D6"), nullptr, 0)); // TweenComplete
vm_unity32(BpOff1454, strtoul(ENCRYPT("0xC003B4D6"), nullptr, 0)); // CloseImpl
vm_unity32(BpOff1455, strtoul(ENCRYPT("0xC003B5D6"), nullptr, 0)); // Awake
vm_unity32(BpOff1456, strtoul(ENCRYPT("0xC003B6D6"), nullptr, 0)); // .ctor

// Namespace: 
// BattleScMgr methods
vm_unity32(BpOff1457, strtoul(ENCRYPT("0xC003B7D6"), nullptr, 0)); // get_MovingBuildingInsId
vm_unity32(BpOff1458, strtoul(ENCRYPT("0xC003B8D6"), nullptr, 0)); // set_MovingBuildingInsId
vm_unity32(BpOff1459, strtoul(ENCRYPT("0xC003B9D6"), nullptr, 0)); // get_HideZhunXing
vm_unity32(BpOff1460, strtoul(ENCRYPT("0xC003BAD6"), nullptr, 0)); // set_HideZhunXing
vm_unity32(BpOff1461, strtoul(ENCRYPT("0xC003BBD6"), nullptr, 0)); // get_LoadingTime
vm_unity32(BpOff1462, strtoul(ENCRYPT("0xC003BCD6"), nullptr, 0)); // set_LoadingTime
vm_unity32(BpOff1463, strtoul(ENCRYPT("0xC003BDD6"), nullptr, 0)); // get_EnterBattleTime
vm_unity32(BpOff1464, strtoul(ENCRYPT("0xC003BED6"), nullptr, 0)); // set_EnterBattleTime
vm_unity32(BpOff1465, strtoul(ENCRYPT("0xC003BFD6"), nullptr, 0)); // get_InLoading
vm_unity32(BpOff1466, strtoul(ENCRYPT("0xC003C0D6"), nullptr, 0)); // set_InLoading
vm_unity32(BpOff1467, strtoul(ENCRYPT("0xC003C1D6"), nullptr, 0)); // get_TotalLoadingTime
vm_unity32(BpOff1468, strtoul(ENCRYPT("0xC003C2D6"), nullptr, 0)); // get_TotalBattleTime
vm_unity32(BpOff1469, strtoul(ENCRYPT("0xC003C3D6"), nullptr, 0)); // get_Level
vm_unity32(BpOff1470, strtoul(ENCRYPT("0xC003C4D6"), nullptr, 0)); // get_Exp
vm_unity32(BpOff1471, strtoul(ENCRYPT("0xC003C5D6"), nullptr, 0)); // set_VoiceTeamId
vm_unity32(BpOff1472, strtoul(ENCRYPT("0xC003C6D6"), nullptr, 0)); // get_VoiceTeamId
vm_unity32(BpOff1473, strtoul(ENCRYPT("0xC003C7D6"), nullptr, 0)); // get_IsBsConnect
vm_unity32(BpOff1474, strtoul(ENCRYPT("0xC003C8D6"), nullptr, 0)); // get_SceneHeightInfo
vm_unity32(BpOff1475, strtoul(ENCRYPT("0xC003C9D6"), nullptr, 0)); // set_SceneHeightInfo
vm_unity32(BpOff1476, strtoul(ENCRYPT("0xC003CAD6"), nullptr, 0)); // Init
vm_unity32(BpOff1477, strtoul(ENCRYPT("0xC003CBD6"), nullptr, 0)); // OnSelfDie
vm_unity32(BpOff1478, strtoul(ENCRYPT("0xC003CCD6"), nullptr, 0)); // OnSMapObjectHasParent
vm_unity32(BpOff1479, strtoul(ENCRYPT("0xC003CDD6"), nullptr, 0)); // RemoveInsIdInParentIdDic
vm_unity32(BpOff1480, strtoul(ENCRYPT("0xC003CED6"), nullptr, 0)); // OnSVoiceTeamId
vm_unity32(BpOff1481, strtoul(ENCRYPT("0xC003CFD6"), nullptr, 0)); // OnSBsServerInfo
vm_unity32(BpOff1482, strtoul(ENCRYPT("0xC003D0D6"), nullptr, 0)); // InitBloodEffectPath
vm_unity32(BpOff1483, strtoul(ENCRYPT("0xC003D1D6"), nullptr, 0)); // OnSMapToolBoxHasMaterail
vm_unity32(BpOff1484, strtoul(ENCRYPT("0xC003D2D6"), nullptr, 0)); // OnSDestoryPreviewBuilding
vm_unity32(BpOff1485, strtoul(ENCRYPT("0xC003D3D6"), nullptr, 0)); // SRadiationHandle
vm_unity32(BpOff1486, strtoul(ENCRYPT("0xC003D4D6"), nullptr, 0)); // SEnterRadiationHandle
vm_unity32(BpOff1487, strtoul(ENCRYPT("0xC003D5D6"), nullptr, 0)); // SLeaveRadiationHandle
vm_unity32(BpOff1488, strtoul(ENCRYPT("0xC003D6D6"), nullptr, 0)); // SBattleExpHandle
vm_unity32(BpOff1489, strtoul(ENCRYPT("0xC003D7D6"), nullptr, 0)); // OnSwichHandWeapon
vm_unity32(BpOff1490, strtoul(ENCRYPT("0xC003D8D6"), nullptr, 0)); // OnSwichBagGun
vm_unity32(BpOff1491, strtoul(ENCRYPT("0xC003D9D6"), nullptr, 0)); // OnSSynSkinWeaponKillNum
vm_unity32(BpOff1492, strtoul(ENCRYPT("0xC003DAD6"), nullptr, 0)); // OnDestoryBuilding
vm_unity32(BpOff1493, strtoul(ENCRYPT("0xC003DBD6"), nullptr, 0)); // OnPartBuildFinished
vm_unity32(BpOff1494, strtoul(ENCRYPT("0xC003DCD6"), nullptr, 0)); // OnRecycleBuilding
vm_unity32(BpOff1495, strtoul(ENCRYPT("0xC003DDD6"), nullptr, 0)); // CheckNeedRemoveInToolBoxHasMaterailHashSet
vm_unity32(BpOff1496, strtoul(ENCRYPT("0xC003DED6"), nullptr, 0)); // OnSLeaveBuilding
vm_unity32(BpOff1497, strtoul(ENCRYPT("0xC003DFD6"), nullptr, 0)); // RecycleBuildPart
vm_unity32(BpOff1498, strtoul(ENCRYPT("0xC003E0D6"), nullptr, 0)); // ResetTizi
vm_unity32(BpOff1499, strtoul(ENCRYPT("0xC003E1D6"), nullptr, 0)); // GetBuildPartByLv1Id
vm_unity32(BpOff1500, strtoul(ENCRYPT("0xC003E2D6"), nullptr, 0)); // GetBuildPartIdBySetting
vm_unity32(BpOff1501, strtoul(ENCRYPT("0xC003E3D6"), nullptr, 0)); // GetBuildPartAutoPutSkin
vm_unity32(BpOff1502, strtoul(ENCRYPT("0xC003E4D6"), nullptr, 0)); // get_IsAllBuildingCreated
vm_unity32(BpOff1503, strtoul(ENCRYPT("0xC003E5D6"), nullptr, 0)); // OnSEnterBuildings
vm_unity32(BpOff1504, strtoul(ENCRYPT("0xC003E6D6"), nullptr, 0)); // IsJustBuilt
vm_unity32(BpOff1505, strtoul(ENCRYPT("0xC003E7D6"), nullptr, 0)); // IsCarPart
vm_unity32(BpOff1506, strtoul(ENCRYPT("0xC003E8D6"), nullptr, 0)); // OnSBuildRootPart
vm_unity32(BpOff1507, strtoul(ENCRYPT("0xC003E9D6"), nullptr, 0)); // IsRoof
vm_unity32(BpOff1508, strtoul(ENCRYPT("0xC003EAD6"), nullptr, 0)); // IsBuildCross
vm_unity32(BpOff1509, strtoul(ENCRYPT("0xC003EBD6"), nullptr, 0)); // CheckBuildRoofCross
vm_unity32(BpOff1510, strtoul(ENCRYPT("0xC003ECD6"), nullptr, 0)); // isNeedCheckBuildError
vm_unity32(BpOff1511, strtoul(ENCRYPT("0xC003EDD6"), nullptr, 0)); // CheckBuildError
vm_unity32(BpOff1512, strtoul(ENCRYPT("0xC003EED6"), nullptr, 0)); // Send108
vm_unity32(BpOff1513, strtoul(ENCRYPT("0xC003EFD6"), nullptr, 0)); // OnSReBuildJiajv
vm_unity32(BpOff1514, strtoul(ENCRYPT("0xC003F0D6"), nullptr, 0)); // OnWantPlacedPart
vm_unity32(BpOff1515, strtoul(ENCRYPT("0xC003F1D6"), nullptr, 0)); // OnWantDestoryBuilding
vm_unity32(BpOff1516, strtoul(ENCRYPT("0xC003F2D6"), nullptr, 0)); // SQuitBattleHandel
vm_unity32(BpOff1517, strtoul(ENCRYPT("0xC003F3D6"), nullptr, 0)); // OnSBattleLoginFinish
vm_unity32(BpOff1518, strtoul(ENCRYPT("0xC003F4D6"), nullptr, 0)); // OpenBattleLoadingPanel
vm_unity32(BpOff1519, strtoul(ENCRYPT("0xC003F5D6"), nullptr, 0)); // ShowLoadingPanelEvent
vm_unity32(BpOff1520, strtoul(ENCRYPT("0xC003F6D6"), nullptr, 0)); // LoadBattleScene
vm_unity32(BpOff1521, strtoul(ENCRYPT("0xC003F7D6"), nullptr, 0)); // SetUiCamEnable
vm_unity32(BpOff1522, strtoul(ENCRYPT("0xC003F8D6"), nullptr, 0)); // Dosame
vm_unity32(BpOff1523, strtoul(ENCRYPT("0xC003F9D6"), nullptr, 0)); // SceneLoadCompleteCallBack
vm_unity32(BpOff1524, strtoul(ENCRYPT("0xC003FAD6"), nullptr, 0)); // SendLoadFinish
vm_unity32(BpOff1525, strtoul(ENCRYPT("0xC003FBD6"), nullptr, 0)); // SendJoystickAutoMove
vm_unity32(BpOff1526, strtoul(ENCRYPT("0xC003FCD6"), nullptr, 0)); // ReConnect
vm_unity32(BpOff1527, strtoul(ENCRYPT("0xC003FDD6"), nullptr, 0)); // ExitGame
vm_unity32(BpOff1528, strtoul(ENCRYPT("0xC003FED6"), nullptr, 0)); // GetAudioPercent
vm_unity32(BpOff1529, strtoul(ENCRYPT("0xC003FFD6"), nullptr, 0)); // SendBuildChildPartMsg
vm_unity32(BpOff1530, strtoul(ENCRYPT("0xC00400D6"), nullptr, 0)); // SendBuildRootPartMsg
vm_unity32(BpOff1531, strtoul(ENCRYPT("0xC00401D6"), nullptr, 0)); // SendBuildJiajvMsg
vm_unity32(BpOff1532, strtoul(ENCRYPT("0xC00402D6"), nullptr, 0)); // SendDestoryBuildingMsg
vm_unity32(BpOff1533, strtoul(ENCRYPT("0xC00403D6"), nullptr, 0)); // AddForceDie
vm_unity32(BpOff1534, strtoul(ENCRYPT("0xC00404D6"), nullptr, 0)); // DisableBattleCamera
vm_unity32(BpOff1535, strtoul(ENCRYPT("0xC00405D6"), nullptr, 0)); // DisableBattleSomeUI
vm_unity32(BpOff1536, strtoul(ENCRYPT("0xC00406D6"), nullptr, 0)); // OpenBattleCamera
vm_unity32(BpOff1537, strtoul(ENCRYPT("0xC00407D6"), nullptr, 0)); // OpenBattleSomeUI
vm_unity32(BpOff1538, strtoul(ENCRYPT("0xC00408D6"), nullptr, 0)); // QuickBattle
vm_unity32(BpOff1539, strtoul(ENCRYPT("0xC00409D6"), nullptr, 0)); // ShowBattlePanel
vm_unity32(BpOff1540, strtoul(ENCRYPT("0xC0040AD6"), nullptr, 0)); // get_IsShowBattlePanel
vm_unity32(BpOff1541, strtoul(ENCRYPT("0xC0040BD6"), nullptr, 0)); // set_IsShowBattlePanel
vm_unity32(BpOff1542, strtoul(ENCRYPT("0xC0040CD6"), nullptr, 0)); // HideBattlePanel
vm_unity32(BpOff1543, strtoul(ENCRYPT("0xC0040DD6"), nullptr, 0)); // EnterBattle
vm_unity32(BpOff1544, strtoul(ENCRYPT("0xC0040ED6"), nullptr, 0)); // OutBattle
vm_unity32(BpOff1545, strtoul(ENCRYPT("0xC0040FD6"), nullptr, 0)); // ResetNoBehaviorInOfficialBaseTime
vm_unity32(BpOff1546, strtoul(ENCRYPT("0xC00410D6"), nullptr, 0)); // OnSelfStateChange
vm_unity32(BpOff1547, strtoul(ENCRYPT("0xC00411D6"), nullptr, 0)); // OnPlayerHaveBehavior
vm_unity32(BpOff1548, strtoul(ENCRYPT("0xC00412D6"), nullptr, 0)); // SecondUpdate
vm_unity32(BpOff1549, strtoul(ENCRYPT("0xC00413D6"), nullptr, 0)); // ShowKickOutBattleUI
vm_unity32(BpOff1550, strtoul(ENCRYPT("0xC00414D6"), nullptr, 0)); // ClearOvertimeBuildingRecord
vm_unity32(BpOff1551, strtoul(ENCRYPT("0xC00415D6"), nullptr, 0)); // ShowBuildLoadingPanel
vm_unity32(BpOff1552, strtoul(ENCRYPT("0xC00416D6"), nullptr, 0)); // OnSBuildAlert
vm_unity32(BpOff1553, strtoul(ENCRYPT("0xC00417D6"), nullptr, 0)); // HideBuildLoadingPanel
vm_unity32(BpOff1554, strtoul(ENCRYPT("0xC00418D6"), nullptr, 0)); // OffCameraRotationFree
vm_unity32(BpOff1555, strtoul(ENCRYPT("0xC00419D6"), nullptr, 0)); // IsSelfControl
vm_unity32(BpOff1556, strtoul(ENCRYPT("0xC0041AD6"), nullptr, 0)); // get_AudioIdRadiation
vm_unity32(BpOff1557, strtoul(ENCRYPT("0xC0041BD6"), nullptr, 0)); // set_AudioIdRadiation
vm_unity32(BpOff1558, strtoul(ENCRYPT("0xC0041CD6"), nullptr, 0)); // ChangeRadiationSound
vm_unity32(BpOff1559, strtoul(ENCRYPT("0xC0041DD6"), nullptr, 0)); // CheckInRadiation
vm_unity32(BpOff1560, strtoul(ENCRYPT("0xC0041ED6"), nullptr, 0)); // CalDisToSelf
vm_unity32(BpOff1561, strtoul(ENCRYPT("0xC0041FD6"), nullptr, 0)); // DisableShowPlayerInfor

// Namespace: 
// Battle methods
vm_unity32(BpOff1562, strtoul(ENCRYPT("0xC00420D6"), nullptr, 0)); // get_IsSelfFlyingWrj
vm_unity32(BpOff1563, strtoul(ENCRYPT("0xC00421D6"), nullptr, 0)); // ReportIsSimulator

// Namespace: ano
// AnoInfoPublisher methods
vm_unity32(BpOff1564, strtoul(ENCRYPT("0xC00422D6"), nullptr, 0)); // .ctor
vm_unity32(BpOff1565, strtoul(ENCRYPT("0xC00423D6"), nullptr, 0)); // getInstance
vm_unity32(BpOff1566, strtoul(ENCRYPT("0xC00424D6"), nullptr, 0)); // registAnoInfoReceiver
vm_unity32(BpOff1567, strtoul(ENCRYPT("0xC00425D6"), nullptr, 0)); // broadcastInfo
vm_unity32(BpOff1568, strtoul(ENCRYPT("0xC00426D6"), nullptr, 0)); // recvDataThread
vm_unity32(BpOff1569, strtoul(ENCRYPT("0xC00427D6"), nullptr, 0)); // openPipe
vm_unity32(BpOff1570, strtoul(ENCRYPT("0xC00428D6"), nullptr, 0)); // closePipe
vm_unity32(BpOff1571, strtoul(ENCRYPT("0xC00429D6"), nullptr, 0)); // recvPipe
vm_unity32(BpOff1572, strtoul(ENCRYPT("0xC0042AD6"), nullptr, 0)); // .cctor

// Namespace: 
// RechargeMgr methods
vm_unity32(BpOff1573, strtoul(ENCRYPT("0xC0042BD6"), nullptr, 0)); // get_CurBsInfo
vm_unity32(BpOff1574, strtoul(ENCRYPT("0xC0042CD6"), nullptr, 0)); // get_ZhanJuMode
vm_unity32(BpOff1575, strtoul(ENCRYPT("0xC0042DD6"), nullptr, 0)); // IsZhanJuMode

// Namespace: 
// AllianceWarMgr methods
vm_unity32(BpOff1576, strtoul(ENCRYPT("0xC0042ED6"), nullptr, 0)); // SendCGetAllianceWarBsInfo
vm_unity32(BpOff1577, strtoul(ENCRYPT("0xC0042FD6"), nullptr, 0)); // SendCGetGsAllianceWarRank
vm_unity32(BpOff1578, strtoul(ENCRYPT("0xC00430D6"), nullptr, 0)); // OnSGetAllianceWarBsInfo

// Namespace: bs.chat.scmsg
// BsMsgBean methods
vm_unity32(BpOff1579, strtoul(ENCRYPT("0xC00431D6"), nullptr, 0)); // .ctor
vm_unity32(BpOff1580, strtoul(ENCRYPT("0xC00432D6"), nullptr, 0)); // marshal
vm_unity32(BpOff1581, strtoul(ENCRYPT("0xC00433D6"), nullptr, 0)); // unmarshal
vm_unity32(BpOff1582, strtoul(ENCRYPT("0xC00434D6"), nullptr, 0)); // marshal (overloaded)
vm_unity32(BpOff1583, strtoul(ENCRYPT("0xC00435D6"), nullptr, 0)); // unmarshal (overloaded)
vm_unity32(BpOff1584, strtoul(ENCRYPT("0xC00436D6"), nullptr, 0)); // reset

// Namespace: bs.chat.scmsg
// BsMsgType methods
vm_unity32(BpOff1585, strtoul(ENCRYPT("0xC00437D6"), nullptr, 0)); // .ctor
vm_unity32(BpOff1586, strtoul(ENCRYPT("0xC00438D6"), nullptr, 0)); // marshal
vm_unity32(BpOff1587, strtoul(ENCRYPT("0xC00439D6"), nullptr, 0)); // unmarshal
vm_unity32(BpOff1588, strtoul(ENCRYPT("0xC0043AD6"), nullptr, 0)); // marshal (overloaded)
vm_unity32(BpOff1589, strtoul(ENCRYPT("0xC0043BD6"), nullptr, 0)); // unmarshal (overloaded)
vm_unity32(BpOff1590, strtoul(ENCRYPT("0xC0043CD6"), nullptr, 0)); // reset

// Namespace: bs.chat.scmsg
// CBsPublicMsg methods
vm_unity32(BpOff1591, strtoul(ENCRYPT("0xC0043DD6"), nullptr, 0)); // .ctor
vm_unity32(BpOff1592, strtoul(ENCRYPT("0xC0043ED6"), nullptr, 0)); // handle
vm_unity32(BpOff1593, strtoul(ENCRYPT("0xC0043FD6"), nullptr, 0)); // getType
vm_unity32(BpOff1594, strtoul(ENCRYPT("0xC00440D6"), nullptr, 0)); // marshal
vm_unity32(BpOff1595, strtoul(ENCRYPT("0xC00441D6"), nullptr, 0)); // unmarshal
vm_unity32(BpOff1596, strtoul(ENCRYPT("0xC00442D6"), nullptr, 0)); // marshal (overloaded)
vm_unity32(BpOff1597, strtoul(ENCRYPT("0xC00443D6"), nullptr, 0)); // unmarshal (overloaded)
vm_unity32(BpOff1598, strtoul(ENCRYPT("0xC00444D6"), nullptr, 0)); // reset
vm_unity32(BpOff1599, strtoul(ENCRYPT("0xC00445D6"), nullptr, 0)); // <>iFixBaseProxy_reset

// Namespace: bs.chat.scmsg
// SBsPublicMsg methods
vm_unity32(BpOff1600, strtoul(ENCRYPT("0xC00446D6"), nullptr, 0)); // .ctor
vm_unity32(BpOff1601, strtoul(ENCRYPT("0xC00447D6"), nullptr, 0)); // handle
vm_unity32(BpOff1602, strtoul(ENCRYPT("0xC00448D6"), nullptr, 0)); // getType
vm_unity32(BpOff1603, strtoul(ENCRYPT("0xC00449D6"), nullptr, 0)); // marshal
vm_unity32(BpOff1604, strtoul(ENCRYPT("0xC0044AD6"), nullptr, 0)); // unmarshal
vm_unity32(BpOff1605, strtoul(ENCRYPT("0xC0044BD6"), nullptr, 0)); // marshal (overloaded)
vm_unity32(BpOff1606, strtoul(ENCRYPT("0xC0044CD6"), nullptr, 0)); // unmarshal (overloaded)
vm_unity32(BpOff1607, strtoul(ENCRYPT("0xC0044DD6"), nullptr, 0)); // reset
vm_unity32(BpOff1608, strtoul(ENCRYPT("0xC0044ED6"), nullptr, 0)); // <>iFixBaseProxy_reset

            }
        bypass_active = YES;
    }
    else{
        if(bypass_active == YES){

            }
        bypass_active = NO;
    }


if(instantexp){
        if(instantexp_active == NO){
            vm_unity32(InstantExpOffset, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
            }
        instantexp_active = YES;
    }
    else{
        if(instantexp_active == YES){
            vm_unity32(InstantExpOffset, strtoul(ENCRYPT("0xE923BC6D"), nullptr, 0));
            }
        instantexp_active = NO;
    }

if(admesp){
        if(admesp_active == NO){
            vm_unity(AdmEspOffset, strtoul(ENCRYPT("0x200080D2C0035FD6"), nullptr, 0));
            }
        admesp_active = YES;
    }
    else{
        if(admesp_active == YES){
            vm_unity(AdmEspOffset, strtoul(ENCRYPT("0xF44FBEA9FD7B01A9"), nullptr, 0));
            }
        admesp_active = NO;
    }

if(noenemyanim){
        if(noenemyanim_active == NO){
            vm_unity32(NoEnemyAnimOffset1, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
            vm_unity32(NoEnemyAnimOffset2, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
            }
        noenemyanim_active = YES;
    }
    else{
        if(noenemyanim_active == YES){
            vm_unity32(NoEnemyAnimOffset1, strtoul(ENCRYPT("0xE923BB6D"), nullptr, 0));
            vm_unity32(NoEnemyAnimOffset2, strtoul(ENCRYPT("0xE923BB6D"), nullptr, 0));
            }
        noenemyanim_active = NO;
    }


if(traceroff){
        if(traceroff_active == NO){

            }
        traceroff_active = YES;
    }
    else{
        if(traceroff_active == YES){

            }
        traceroff_active = NO;
    }

if(rpgoff){
        if(rpgoff_active == NO){
            vm_unity32(RpgOffOffset, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
            }
        rpgoff_active = YES;
    }
    else{
        if(rpgoff_active == YES){
            vm_unity32(RpgOffOffset, strtoul(ENCRYPT("0xFF8301D1"), nullptr, 0));
            }
        rpgoff_active = NO;
    }

if(drinkwater){
        if(drinkwater_active == NO){
            vm_unity32(DrinkWaterOffset, strtoul(ENCRYPT("0xC0035FD6"), nullptr, 0));
            }
        drinkwater_active = YES;
    }
    else{
        if(drinkwater_active == YES){
            vm_unity32(DrinkWaterOffset, strtoul(ENCRYPT("0xF44FBEA9"), nullptr, 0));
            }
        drinkwater_active = NO;
    }

}


}