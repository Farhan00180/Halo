//Require standard library
#import <Metal/Metal.h>
#import <MetalKit/MetalKit.h>
#import <Foundation/Foundation.h>
#include <iostream>
#include <fstream>
//Imgui library
#import "Esp/ImGuiDrawView.h"
#import "IMGUI/imgui.h"
#import "IMGUI/imgui_impl_metal.h"
#import "IMGUI/imgui-fokusi.h"
#import "IMGUI/imgui_internal.h"
//Patch library
#import "utils/NakanoIchika.h"
#import "utils/NakanoNino.h"
#import "utils/NakanoMiku.h"
#import "utils/NakanoYotsuba.h" 
#include "utils/oxorany_include.h"
#import "utils/dobby.h"
#import "utils/il2cpp/il2cpp.h"
#import "utils/Vector3.h"
#import "utils/Monostring.h"
//some another helpers
#import "variables.h"
#import "functions/autoupdate.h"
#import "functions/offsets.h"
#import "functions/igg.h"
#import "functions/Hooks.h"
ImFont *font;
#import "functions/ESP/main.h"
#import "functions/ESP/classHexIpa.h"
#import "font.h"
#import "font2.h"

#define kWidth  [UIScreen mainScreen].bounds.size.width
#define kHeight [UIScreen mainScreen].bounds.size.height
#define kScale [UIScreen mainScreen].scale


@interface ImGuiDrawView () <MTKViewDelegate>
@property (nonatomic, strong) id <MTLDevice> device;
@property (nonatomic, strong) id <MTLCommandQueue> commandQueue;
@end

@implementation ImGuiDrawView

NSString *appVersion = [[NSBundle mainBundle] objectForInfoDictionaryKey:NSENC("CFBundleShortVersionString")];
NSString *appVersionTrue = NSENC("2.35.0");
NSString *buildVersion = [[NSBundle mainBundle] objectForInfoDictionaryKey:NSENC("CFBundleVersion")];

UIButton *UP,*LOCK,*DOWN,*NOCLIP,*SOUL,*LOGIN;



#define Dobby(offset, ptr, orig) DobbyHook(reinterpret_cast<void*>(getRealOffset(offset)), reinterpret_cast<void*>(ptr), reinterpret_cast<void**>(&orig))

- (instancetype)initWithNibName:(nullable NSString *)nibNameOrNil bundle:(nullable NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];

    _device = MTLCreateSystemDefaultDevice();
    _commandQueue = [_device newCommandQueue];

    if (!self.device) abort();

    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO(); (void)io;

   //io.Fonts->AddFontFromMemoryTTF(&font, sizeof font, 24.0f, NULL, io.Fonts->GetGlyphRangesCyrillic());
        
    //font = io.Fonts->AddFontFromMemoryTTF(&verdana, sizeof verdana, 18.0f);
        
    //static const ImWchar fontt_ranges[] = { 0x0020, 0x00FF, 0x2000, 0x206F, 0x3000, 0x30FF, 0x31F0, 0x31FF, 0xFF00, 0xFFEF, 0xFFFD, 0xFFFD, 0x4E00, 0x9FAF, 0x0400, 0x052F, 0x2DE0, 0x2DFF, 0xA640, 0xA69F, 0 };


    font = io.Fonts->AddFontFromMemoryTTF(Asap_Light_ttf, Asap_SemiBold_ttf_len, 27.0f, NULL, io.Fonts->GetGlyphRangesCyrillic());

    io.Fonts->AddFontFromMemoryTTF(Asap_Light_ttf, Asap_SemiBold_ttf_len, 25.0f, NULL, io.Fonts->GetGlyphRangesCyrillic());

 //   io.Fonts->AddFontFromMemoryTTF(Asap_Light_ttf, Asap_Light_ttf_len, 60.0f, NULL, io.Fonts->GetGlyphRangesCyrillic());

    //Font = io.Fonts->AddFontFromMemoryTTF(Asap_SemiBold_ttf, Asap_SemiBold_ttf_len, 30.0f, NULL, io.Fonts->GetGlyphRangesCyrillic());


    ImGui::StyleColorsClassic();
    
    ImGui_ImplMetal_Init(_device);

    return self;
}

+ (void)showChange:(BOOL)open
{
    userInteraction = open;
}

- (MTKView *)mtkView
{
    return (MTKView *)self.view;
}

- (void)loadView
{
    CGFloat w = [UIApplication sharedApplication].windows[0].rootViewController.view.frame.size.width;
    CGFloat h = [UIApplication sharedApplication].windows[0].rootViewController.view.frame.size.height;
    self.view = [[MTKView alloc] initWithFrame:CGRectMake(0, 0, w, h)];
}


- (void)viewDidLoad {

    [super viewDidLoad];
    
    self.mtkView.device = self.device;
    self.mtkView.delegate = self;
    self.mtkView.clearColor = MTLClearColorMake(0, 0, 0, 0);
    self.mtkView.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0];
    self.mtkView.clipsToBounds = YES;


dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
    enemy = new enemy_t();
    me = new me_t();
    Mine = new Mine_t();
    initial_setup();
    OpenURL(NSENC("https://t.me/trollwareios"));
    HexIpa->init();
    

    //pthread_t WorldEditThread;
    //pthread_create(&WorldEditThread, nullptr, WorldEdit, nullptr);
});

}

#pragma mark - Interaction

- (void)updateIOWithTouchEvent:(UIEvent *)event
{
    UITouch *anyTouch = event.allTouches.anyObject;
    CGPoint touchLocation = [anyTouch locationInView:self.view];
    ImGuiIO &io = ImGui::GetIO();
    io.MousePos = ImVec2(touchLocation.x, touchLocation.y);

    BOOL hasActiveTouch = NO;
    for (UITouch *touch in event.allTouches)
    {
        if (touch.phase != UITouchPhaseEnded && touch.phase != UITouchPhaseCancelled)
        {
            hasActiveTouch = YES;
            break;
        }
    }
    io.MouseDown[0] = hasActiveTouch;
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [self updateIOWithTouchEvent:event];
}

- (void)touchesMoved:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [self updateIOWithTouchEvent:event];
}

- (void)touchesCancelled:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [self updateIOWithTouchEvent:event];
}

- (void)touchesEnded:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [self updateIOWithTouchEvent:event];
}

#pragma mark - MTKViewDelegate



- (void)drawInMTKView:(MTKView*)view
{
    
    ImGuiIO& io = ImGui::GetIO();
    io.DisplaySize.x = view.bounds.size.width;
    io.DisplaySize.y = view.bounds.size.height;

static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
    CGFloat width = kWidth * 0.5;
    CGFloat height = kHeight * 0.5;
    if (kWidth > kHeight) {
        height = kHeight * 0.8;
    } else {
        width = kWidth * 0.8;
    }
    ImGuiIO & io = ImGui::GetIO();

    io.DisplaySize = ImVec2(width + 30, height);
        //ImGui::SetNextWindowPos(ImVec2(0, 0), ImGuiCond_FirstUseEver);
    ImGui::SetNextWindowPos(ImVec2((kWidth - width) * 0.5, (kHeight - height) * 0.5), 0, ImVec2(0, 0));
    ImGui::SetNextWindowSize(ImVec2(io.DisplaySize.x/1, io.DisplaySize.y/1));

    ImGuiStyle* style = &ImGui::GetStyle();

    style->WindowPadding            = ImVec2(15, 15);
    style->WindowRounding           = 12.0f;
    style->FramePadding             = ImVec2(10, 5);
    style->FrameRounding            = 12.0f;
    style->ItemSpacing              = ImVec2(5, 4);
    style->ItemInnerSpacing         = ImVec2(7, 5);
    style->IndentSpacing            = 15.0f;
    style->ScrollbarSize            = 24.0f;
    style->ScrollbarRounding        = 9.0f;
    style->GrabMinSize              = 16.0f; 
    style->GrabRounding             = 3.0f; 
    });

 


    CGFloat framebufferScale = view.window.screen.scale ?: UIScreen.mainScreen.scale;
    io.DisplayFramebufferScale = ImVec2(framebufferScale, framebufferScale);
    io.DeltaTime = 1 / float(view.preferredFramesPerSecond ?: 120);
    
    id<MTLCommandBuffer> commandBuffer = [self.commandQueue commandBuffer];
    
        
        if (userInteraction == true) {
            [self.view setUserInteractionEnabled:YES];
        } else if (userInteraction == false) {
            [self.view setUserInteractionEnabled:NO];
        }

        MTLRenderPassDescriptor* renderPassDescriptor = view.currentRenderPassDescriptor;
        if (renderPassDescriptor != nil)
        {
            id <MTLRenderCommandEncoder> renderEncoder = [commandBuffer renderCommandEncoderWithDescriptor:renderPassDescriptor];
            [renderEncoder pushDebugGroup:NSENC("ImGui Jane")];

            ImGui_ImplMetal_NewFrame(renderPassDescriptor);
            ImGui::NewFrame();
            
            font = ImGui::GetFont();
            font->Scale = 15.f / font->FontSize;
            
            CGFloat x = (([UIApplication sharedApplication].windows[0].rootViewController.view.frame.size.width) - 360) / 2;
            CGFloat y = (([UIApplication sharedApplication].windows[0].rootViewController.view.frame.size.height) - 300) / 2;
            
            ImGui::SetNextWindowSize(ImVec2(io.DisplaySize.x/2, io.DisplaySize.y/2), ImGuiCond_FirstUseEver);
            
            if (userInteraction)
            {                
               

ImGui::Begin(oxorany("TROLLWARE FREE TELEGRAM @xdfalmik @TROLLWAREIOS"), &userInteraction);

NSString *versionString = [NSString stringWithFormat:NSENC("Game version: %@ (Build %@)"), appVersion, buildVersion];
const char *versionCString = [versionString UTF8String];

ImGui::Text(ENC("%s"), versionCString);

ImGui::RadioButton(ENC("Jailbreak"), &isJb, 1);
ImGui::SameLine();
ImGui::RadioButton(ENC("IPA"), &isJb, 0);

if (ImGui::BeginTabBar(oxorany("HEXIPA"), ImGuiTabBarFlags_NoTooltip|ImGuiTabBarFlags_Reorderable)){
if (ImGui::BeginTabItem(ENCRYPT("Main"))){  
            ImGui::Spacing();

ImGui::Checkbox(ENCRYPT("aimhelpergame"), &aimhelpergame); 
            ImGui::Checkbox(ENCRYPT("bullet Track"), &Silnet);
            ImGui::Spacing();
            ImGui::Checkbox(ENCRYPT("sleep check"), &sleepchecks);
            ImGui::Spacing();
            ImGui::SliderFloat("distance", &bulletdist, 1.0f, 500.0f, "%.2f");
    
if(ImGui::CollapsingHeader(ENCRYPT("Map functions"))){

if(ImGui::Checkbox(ENCRYPT("No textures"), &notexture)){offsetFunc();}
ImGui::SameLine(240);
if(ImGui::Checkbox(ENCRYPT("No tree"), &notree)){offsetFunc();}
ImGui::SameLine(480);
if(ImGui::Checkbox(ENCRYPT("No grass"), &nograss)){offsetFunc();}
if(ImGui::Checkbox(ENCRYPT("Extended build"), &exbuild)){offsetFunc();}
ImGui::SameLine(240);
if(ImGui::Checkbox(ENCRYPT("Lock time"), &locktime)){offsetFunc();}
ImGui::SameLine(480);
if(ImGui::Checkbox(ENCRYPT("Night mode"), &picture)){offsetFunc();}
if(ImGui::Checkbox(ENCRYPT("Instant Explosion"), &instantexp)){offsetFunc();}
ImGui::SameLine(240);
if(ImGui::Checkbox(ENCRYPT("Force build"), &forcebuild)){offsetFunc();}

}
                   

if(ImGui::CollapsingHeader(ENCRYPT("Character functions"))){

ImGui::Checkbox(ENCRYPT("GM"), &gm);
ImGui::SameLine(240);
if(ImGui::Checkbox(ENCRYPT("Name"), &name)){offsetFunc();}
ImGui::SameLine(480);
if(ImGui::Checkbox(ENCRYPT("Fake owner"), &fakeowner)){offsetFunc();}
if(ImGui::Checkbox(ENCRYPT("No fall damage"), &nofalldamage)){offsetFunc();}
ImGui::SameLine(240);
if(ImGui::Checkbox(ENCRYPT("Underwater walk"), &underwater)){offsetFunc();}
ImGui::SameLine(480);
if(ImGui::Checkbox(ENCRYPT("Ignore npc"), &mtt)){offsetFunc();}
if(ImGui::Checkbox(ENCRYPT("No shake"), &noshake)){offsetFunc();}
ImGui::SameLine(240);
if(ImGui::Checkbox(ENCRYPT("Soul"), &soul)){offsetFunc();}

}

if(ImGui::CollapsingHeader(ENCRYPT("Weapon"))){

if(ImGui::Checkbox(ENCRYPT("No recoil"), &norecoil)){offsetFunc();}
ImGui::SameLine(240);
if(ImGui::Checkbox(ENCRYPT("No spread"), &nospread)){offsetFunc();}

}

if(ImGui::Checkbox(ENCRYPT("Bypass"), &bypass)){
//saveoff();
offsetFunc();
}

ImGui::EndTabItem();
   }
}
            
if (ImGui::BeginTabItem(ENCRYPT("IGG"))) {
if (ImGui::CollapsingHeader(ENCRYPT("PVP"))){

if(ImGui::Checkbox(ENCRYPT("Instant RPG"), &instantrpg)){iggFunc();}
ImGui::SameLine(220);
if(ImGui::Checkbox(ENCRYPT("Magic 0.6"), &magic06)){iggFunc();}
ImGui::SameLine(440);
if(ImGui::Checkbox(ENCRYPT("Magic 1.2"), &magic12)){iggFunc();}

if(ImGui::Checkbox(ENCRYPT("Magic 2.0"), &magicbullet)){iggFunc();}
ImGui::SameLine(220);
if(ImGui::Checkbox(ENCRYPT("Magic knife 0.6"), &knife06)){iggFunc();}
ImGui::SameLine(440);
if(ImGui::Checkbox(ENCRYPT("Magic knife 1.2"), &knife12)){iggFunc();}

if(ImGui::Checkbox(ENCRYPT("Magic knife 2.0"), &magicknife)){iggFunc();}
ImGui::SameLine(220);
if(ImGui::Checkbox(ENCRYPT("RAGE Magic"), &magic120)){iggFunc();}
ImGui::SameLine(440);
if(ImGui::Checkbox(ENCRYPT("RAGE Knife"), &knife120)){iggFunc();}

   }

if(ImGui::CollapsingHeader(ENCRYPT("Map function") )){            

if (ImGui::Checkbox(ENCRYPT("Water build" ), &waterbuild)) {iggFunc();}
ImGui::SameLine(220);
if (ImGui::Checkbox(ENCRYPT("Delete map"), &deletemap)) {
   /*if (deletemap) {
      JRMemoryEngine zidanchuantu = JRMemoryEngine(mach_task_self());
      AddrRange range = (AddrRange){0x100000000,0x140000000};
      int32_t search = 10000;
      zidanchuantu.JRScanMemory(range, &search, JR_Search_Type_SInt);
      int32_t Nearsearch = 100;
      zidanchuantu.JRNearBySearch(0x12,&Nearsearch,JR_Search_Type_SInt);
      int32_t Nearsearch1 = 5000;
      zidanchuantu.JRNearBySearch(0x50,&Nearsearch1,JR_Search_Type_SInt);
      int32_t search1 = 5000;
      zidanchuantu.JRScanMemory(range, &search1, JR_Search_Type_SInt);
      vector<void*>results = zidanchuantu.getResults(100);
      int32_t modify = -999;
      for(int i =0;i<results.size();i++){
         zidanchuantu.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_SInt);
         }
      } else {
      JRMemoryEngine zidanchuantu = JRMemoryEngine(mach_task_self());
      AddrRange range = (AddrRange){0x100000000,0x140000000};
      int32_t search = 10000;
      zidanchuantu.JRScanMemory(range, &search, JR_Search_Type_SInt);
      int32_t Nearsearch = 100;
      zidanchuantu.JRNearBySearch(0x12,&Nearsearch,JR_Search_Type_SInt);
      int32_t Nearsearch1 = -999;
      zidanchuantu.JRNearBySearch(0x50,&Nearsearch1,JR_Search_Type_SInt);
      int32_t search1 = -999;
      zidanchuantu.JRScanMemory(range, &search1, JR_Search_Type_SInt);
      vector<void*>results = zidanchuantu.getResults(100);
      int32_t modify = 5000;
      for(int i =0;i<results.size();i++){
         zidanchuantu.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_SInt);
      }
   }*/
}

            

   }
        
        
if(ImGui::CollapsingHeader(ENCRYPT("Character functions"))){

if (ImGui::Checkbox(ENCRYPT("High Fov"), &highfov)) {iggFunc();}
ImGui::SameLine(220);
if (ImGui::Checkbox(ENCRYPT("White Body"), &whitebody)) {iggFunc();}
ImGui::SameLine(440);        
if (ImGui::Checkbox(ENCRYPT("Black Body"), &blackbody)) {iggFunc();}
if (ImGui::Checkbox(ENCRYPT("Fast bike"), &fastbike)){iggFunc();}
ImGui::SameLine(220);
if (ImGui::Checkbox(ENCRYPT("Prevetion Death"), &antideath)){iggFunc();}
ImGui::EndTabItem();

   }
}

if(ImGui::BeginTabItem(ENCRYPT("Misc"))){

if(ImGui::Checkbox(ENCRYPT("Admin ESP(Online players)"), &admesp)){offsetFunc();}ImGui::SameLine(300);
if(ImGui::Checkbox(ENCRYPT("Disable enemy animation"), &noenemyanim)){offsetFunc();}

if(ImGui::Checkbox(ENCRYPT("Disable tracer effect"), &traceroff)){offsetFunc();}ImGui::SameLine(300);
if(ImGui::Checkbox(ENCRYPT("Disable rpg effect"), &rpgoff)){offsetFunc();}

if(ImGui::Checkbox(ENCRYPT("Drink water(lobby)"), &drinkwater)){offsetFunc();}ImGui::SameLine(300);

ImGui::EndTabItem();

}

if(ImGui::BeginTabItem(ENCRYPT("Debug"))){

ImGui::SliderFloat(ENC("clappedFloat"), &clappedFloat, 0.1f, 360.0f, "%.3f");
ImGui::SliderFloat(ENC("topPosFloat"), &topPosFloat, 0.1f, 5.0f, "%.3f");
ImGui::SliderFloat(ENC("botPosFloat"), &botPosFloat, 0.1f, 5.0f, "%.3f");
ImGui::SliderFloat(ENC("calculatedPositionFloat"), &calculatedPositionFloat, 0.1f, 10.0f, "%.3f");


    for(int i = 0; i < enemyInfo.size(); i++){
        ImGui::Text(ENC("%s"), enemyInfo[i].Name.c_str());ImGui::SameLine();
        ImGui::Text(ENC("Position: x:%.2f, y: %.2f, z: %.2f"), enemyInfo[i].pos.x, enemyInfo[i].pos.y, enemyInfo[i].pos.z);ImGui::SameLine();
        ImGui::Text(ENC("Hp: %i/%i"), enemyInfo[i].Hp, enemyInfo[i].MaxHp);
    }

ImGui::EndTabItem();

}

if(ImGui::BeginTabItem(ENCRYPT("ESP"))){

ImGui::Checkbox(ENCRYPT("Draw"), &ESP.Draw);ImGui::SameLine();
ImGui::Checkbox(ENCRYPT("Line"), &ESP.Line);ImGui::SameLine();
ImGui::Checkbox(ENCRYPT("Hp"), &ESP.Hp);
ImGui::Checkbox(ENCRYPT("Distance"), &ESP.Distance);ImGui::SameLine();
ImGui::Checkbox(ENCRYPT("Bones"), &ESP.Bones);ImGui::SameLine();
ImGui::Checkbox(ENCRYPT("Name"), &ESP.Name);
ImGui::Checkbox(ENCRYPT("SVO"), &ESP.ZBox);
/*ImGui::Dummy(ImVec2(0.0f, 5.0f)); 
ImGui::Checkbox(ENCRYPT("Monster ESP"), &MonsterESP.Draw);
ImGui::Checkbox(ENCRYPT("#Line"), &MonsterESP.Line);
ImGui::Checkbox(ENCRYPT("#Name"), &MonsterESP.Name);
ImGui::Dummy(ImVec2(0.0f, 5.0f));
ImGui::Checkbox(ENCRYPT("Draw mine"), &MineESP.Draw);
*/

//ImGui::Checkbox(ENCRYPT("Hp"), &MonsterESP.Hp);ImGui::SameLine();
//ImGui::Checkbox(ENCRYPT("Distance"), &MonsterESP.Distance);




ImGui::EndTabItem();

}

if(ImGui::BeginTabItem(ENCRYPT("Flying"))){

ImGui::Dummy(ImVec2(0.0f, 5.0f)); 
if(ImGui::Button(ENC("Flying"))){
[self updateButtonColors];
[self Flying];
}
ImGui::SliderInt(ENCRYPT("Height per 1 tap"), &FlyingHeight, 0, 20);
ImGui::Dummy(ImVec2(0.0f, 3.0f)); 
if(ImGui::SliderFloat(ENC("Buttons X Position"), &sliderX, 0.0f, [[UIScreen mainScreen] bounds].size.width - 40)){
[self updateButtonPositions];
}
if(ImGui::SliderFloat(ENC("Buttons Y Position"), &sliderY, 0.0f, [[UIScreen mainScreen] bounds].size.height - 240)){
[self updateButtonPositions];
}

ImGui::EndTabItem();

}



ImGui::End();


            } 




            ImDrawList* draw_list = ImGui::GetBackgroundDrawList();
            ImVec2 textSize = ImGui::CalcTextSize(ENC("TG @TROLLWAREIOS"));
            draw_list->AddText(font, 30.0f, ImVec2(io.DisplaySize.x/2 - textSize.x, io.DisplaySize.y/8), IM_COL32(255, 255, 255, 255), ENC("TG @TROLLWAREIOS"));
            startesp();

            ImGui::Render();
            ImDrawData* draw_data = ImGui::GetDrawData();
            ImGui_ImplMetal_RenderDrawData(draw_data, commandBuffer, renderEncoder);
          
            [renderEncoder popDebugGroup];
            [renderEncoder endEncoding];

            [commandBuffer presentDrawable:view.currentDrawable];
        }

        [commandBuffer commit];
}




void saveoff() {
    std::vector<uint64_t*> vars = {
    &NoGrassOffset,
    &ExtendedBuildOffset,
    &SoulOffset,
    &NoShakeOffset,
    &ForceBuildOffset,
    &MttOffset1,
    &MttOffset2,
    &MttOffset3,
    &MttOffset4,
    &MttOffset5,
    &MttOffset6,
    &UnderWaterOffset,
    &NoFallDamageOffset1,
    &NoFallDamageOffset2,
    &NoFallDamageOffset3,
    &FakeOwnerOffset1,
    &FakeOwnerOffset2,
    &FakeOwnerOffset3,
    &FakeOwnerOffset4,
    &NoSpreadOffset1,
    &NoSpreadOffset2,
    &NoRecoilOffset,
    &PictureOffset,
    &LockTimeOffset,
    &NoTreeOffset,
    &NameOffset,
    &NoTextureOffset,
    &BulletControlFixedUpdateOffset,
    &BulletControlOnDestroyOffset,
        &BpOff1,
        &BpOff2,
        &BpOff3,
        &BpOff4,
        &BpOff5,
        &BpOff6,
        &BpOff7,
        &BpOff8,
        &BpOff9,
        &BpOff10,
        &BpOff11,
        &BpOff12,
        &BpOff13,
        &BpOff14,
        &BpOff15,
        &BpOff16,
        &BpOff17,
        &BpOff18,
        &BpOff19,
        &BpOff20,
        &BpOff21,
        &BpOff22,
        &BpOff23,
        &BpOff24,
        &BpOff25,
        &BpOff26,
        &BpOff27,
        &BpOff28,
        &BpOff29,
        &BpOff30,
        &BpOff31,
        &BpOff32,
        &BpOff33,
        &BpOff34,
        &BpOff35,
        &BpOff36,
        &BpOff37,
        &BpOff38,
        &BpOff39,
        &BpOff40,
        &BpOff41,
        &BpOff42,
        &BpOff43,
        &BpOff44,
        &BpOff45,
        &BpOff46,
        &BpOff47,
        &BpOff48,
        &BpOff49,
        &BpOff50,
        &BpOff51,
        &BpOff52,
        &BpOff53,
        &BpOff54,
        &BpOff55,
        &BpOff56,
        &BpOff57,
        &BpOff58,
        &BpOff59,
        &BpOff60,
        &BpOff61,
        &BpOff62,
        &BpOff63,
        &BpOff64,
        &BpOff65,
        &BpOff66,
        &BpOff67,
        &BpOff68,
        &BpOff69,
        &BpOff70,
        &BpOff71,
        &BpOff72,
        &BpOff73,
        &BpOff74,
        &BpOff75,
        &BpOff76,
        &BpOff77,
        &BpOff78,
        &BpOff79,
        &BpOff80,
        &BpOff81,
        &BpOff82,
        &BpOff83,
        &BpOff84,
        &BpOff85,
        &BpOff86,
        &BpOff87,
        &BpOff88,
        &BpOff89,
        &BpOff90,
        &BpOff91,
        &BpOff92,
        &BpOff93,
        &BpOff94,
        &BpOff95,
        &BpOff96,
        &BpOff97,
        &BpOff98,
        &BpOff99,
        &BpOff100,
        &BpOff101,
        &BpOff102,
        &BpOff103,
        &BpOff104,
        &BpOff105,
        &BpOff106,
        &BpOff107,
        &BpOff108,
        &BpOff109,
        &BpOff110,
        &BpOff111,
        &BpOff112,
        &BpOff113,
        &BpOff114,
        &BpOff115,
        &BpOff116,
        &BpOff117,
        &BpOff118,
        &BpOff119,
        &BpOff120,
        &BpOff121,
        &BpOff122,
        &BpOff123,
        &BpOff124,
        &BpOff125,
        &BpOff126,
        &BpOff129,
        &BpOff130,
        &BpOff131,
        &BpOff132,
        &BpOff133,
        &BpOff134,
        &BpOff135,
        &BpOff136,
        &BpOff137,
        &BpOff138,
        &BpOff139,
        &BpOff140,
        &BpOff141,
        &BpOff142,
        &BpOff143,
        &BpOff144,
        &BpOff145,
        &BpOff146,
        &BpOff147,
        &BpOff148,
        &BpOff149,
        &BpOff170,
        &BpOff171,
        &BpOff342,
        &BpOff343,
        &BpOff344,
        &BpOff501,
        &BpOff502,
        &BpOff505,
        &BpOff506,
        &BpOff507,
        &BpOff508,
        &BpOff509,
        &BpOff511,
        &BpOff516,
        &BpOff517,
        &BpOff518,
        &BpOff519,
        &BpOff521,
        &BpOff522,
        &BpOff523,
        &BpOff524,
        &BpOff525,
        &BpOff526,
        &BpOff527,
        &BpOff528,
        &BpOff529,
        &BpOff531,
        &BpOff532,
        &BpOff533,
        &BpOff534,
        &BpOff535,
        &BpOff536,
        &BpOff537,
        &BpOff538,
        &BpOff539,
        &BpOff540,
        &BpOff541,
        &BpOff542,
        &BpOff546,
        &BpOff547,
        &BpOff549,
        &BpOff550,
        &BpOff551,
        &BpOff552,
        &BpOff553,
        &BpOff554,
        &BpOff555,
        &BpOff556,
        &BpOff557,
        &BpOff558,
        &BpOff559,
        &BpOff560,
        &BpOff561,
        &BpOff567,
        &BpOff568,
        &BpOff569,
        &BpOff570,
        &BpOff571,
        &BpOff572,
        &BpOff573,
        &BpOff574,
        &BpOff575,
        &BpOff576,
        &BpOff577,
        &BpOff578,
        &BpOff579,
        &BpOff580,
        &BpOff581,
        &BpOff582,
        &BpOff583,
        &BpOff584,
        &BpOff585,
        &BpOff586,
        &BpOff587,
        &BpOff588,
        &BpOff589,
        &BpOff590,
        &BpOff591,
        &BpOff592,
        &BpOff593,
        &BpOff594,
        &BpOff595,
        &BpOff596,
        &BpOff597,
        &BpOff598,
        &BpOff599,
        &BpOff600,
        &BpOff601,
        &BpOff602,
        &BpOff603,
        &BpOff604,
        &BpOff605,
        &BpOff606,
        &BpOff607,
        &BpOff608,
        &BpOff609,
        &BpOff610,
        &BpOff611,
        &BpOff612,
        &BpOff613,
        &BpOff614,
        &BpOff615,
        &BpOff616,
        &BpOff617,
        &BpOff618,
        &BpOff619,
        &BpOff620,
        &BpOff621,
        &BpOff622,
        &BpOff623,
        &BpOff624,
        &BpOff625,
        &BpOff626,
        &BpOff627,
        &BpOff628,
        &BpOff629,
        &BpOff630,
        &BpOff631,
        &BpOff632,
        &BpOff633,
        &BpOff634,
        &BpOff635,
        &BpOff636,
        &BpOff637,
        &BpOff638,
        &BpOff639,
        &BpOff640,
        &BpOff641,
        &BpOff642,
        &BpOff643,
        &BpOff644,
        &BpOff645,
        &BpOff646,
        &BpOff647,
        &BpOff648,
        &BpOff649,
        &BpOff650,
        &BpOff651,
        &BpOff652,
        &BpOff653,
        &BpOff654,
        &BpOff655,
        &BpOff656,
        &BpOff657,
        &BpOff658,
        &BpOff659,
        &BpOff660,
        &BpOff661,
    &BpOff700,
    &BpOff701,
    &BpOff702,
    &BpOff703,
    &BpOff704,
    &BpOff705,
    &BpOff706,
    &BpOff707,
    &BpOff708,
    &BpOff709,
    &BpOff710,
    &BpOff711,
    &BpOff712,
    &BpOff713,
    &BpOff714,
    &BpOff715,
    &BpOff716,
    &BpOff717,
    &BpOff718,
    &BpOff719,
    &BpOff720,
    &BpOff721,
    &BpOff722,
    &BpOff723,
    &BpOff724,
    &BpOff725,
    &BpOff726,
    &BpOff727,
    &BpOff728,
    &BpOff729,
    &BpOff730,
    &BpOff731,
    &BpOff732,
    &BpOff733,
    &BpOff734,
    &BpOff735,
    &BpOff736,
    &BpOff737,
    &BpOff738,
    &BpOff739,
    &BpOff740,
    &BpOff741,
    &BpOff742,
    &BpOff743,
    &BpOff744,
    &BpOff745,
    &BpOff746,
    &BpOff747,
    &BpOff748,
    &BpOff749,
    &BpOff750,
    &BpOff751,
    &BpOff752,
    &BpOff753,
    &BpOff754,
    &BpOff755,
    &BpOff756,
    &BpOff757,
    &BpOff758,
    &BpOff759,
    &BpOff760,
    &BpOff761,
    &BpOff762,
    &BpOff763,
    &BpOff764,
    &BpOff765,
    &BpOff766,
    &BpOff767,
    &BpOff768,
    &BpOff769,
    &BpOff770,
    &BpOff771,
    &BpOff772,
    &BpOff773,
    &BpOff774,
    &BpOff775,
    &BpOff776,
    &BpOff777,
    &BpOff778,
    &BpOff779,
    &BpOff780,
    &BpOff781,
    &BpOff782,
    &BpOff783,
    &BpOff784,
&BpOff801,
&BpOff802,
&BpOff803,
&BpOff804,
&BpOff805,
&BpOff806,
&BpOff807,
&BpOff808,
&BpOff809,
&BpOff810,
&BpOff811,
&BpOff812,
&BpOff813,
&BpOff814,
&BpOff815,
&BpOff816,
&BpOff817,
&BpOff818,
&BpOff819,
&BpOff820,
&BpOff821,
&BpOff822,
&BpOff823,
&BpOff824,
&BpOff825,
&BpOff826,
&BpOff827,
&BpOff828,
&BpOff829,
&BpOff830,
&BpOff831,
&BpOff832,
&BpOff833,
&BpOff834,
&BpOff835,
&BpOff836,
&BpOff837,
&BpOff838,
&BpOff839,
&BpOff840,
&BpOff841,
&BpOff842,
&BpOff843,
&BpOff844,
&BpOff845,
&BpOff846,
&BpOff847,
&BpOff848,
&BpOff849,
&BpOff850,
&BpOff851,
&BpOff852,
&BpOff853,
&BpOff854,
&BpOff855,
&BpOff856,
&BpOff857,
&BpOff858,
&BpOff859,
&BpOff860,
&BpOff861,
&BpOff862,
&BpOff863,
&BpOff864,
&BpOff865,
&BpOff866,
&BpOff867,
&BpOff868,
&BpOff869,
&BpOff870,
&BpOff871,
&BpOff872,
&BpOff873,
&BpOff874,
&BpOff875,
&BpOff876,
&BpOff877,
&BpOff878,
&BpOff879,
&BpOff880,
&BpOff881,
&BpOff882,
&BpOff883,
&BpOff884,
&BpOff885,
&BpOff886,
&BpOff887,
&BpOff888,
&BpOff889,
&BpOff890,
&BpOff891,
&BpOff892,
&BpOff893,
&BpOff894,
&BpOff895,
&BpOff896,
&BpOff897,
&BpOff898,
&BpOff899,
&BpOff900,
&BpOff901,
&BpOff902,
&BpOff903,
&BpOff904,
&BpOff905,
&BpOff906,
&BpOff907,
&BpOff908,
&BpOff909,
&BpOff910,
&BpOff911,
&BpOff912,
&BpOff913,
&BpOff914,
&BpOff915,
&BpOff916,
&BpOff917,
&BpOff918,
&BpOff919,
&BpOff920,
&BpOff921,
&BpOff922,
&BpOff923,
&BpOff924,
&BpOff925,
&BpOff926,
&BpOff927,
&BpOff928,
&BpOff929,
&BpOff930,
&BpOff931,
&BpOff932,
&BpOff933,
&BpOff934,
&BpOff935,
&BpOff936,
&BpOff937,
&BpOff938,
&BpOff939,
&BpOff940,
&BpOff941,
&BpOff942,
&BpOff943,
&BpOff944,
&BpOff945,
&BpOff946,
&BpOff947,
&BpOff948,
&BpOff949,
&BpOff950,
&BpOff951,
&BpOff952,
&BpOff953,
&BpOff954,
&BpOff955,
&BpOff956,
&BpOff957,
&BpOff958,
&BpOff959,
&BpOff960,
&BpOff961,
&BpOff962,
&BpOff963,
&BpOff964,
&BpOff965,
&BpOff966,
&BpOff967,
&BpOff968,
&BpOff969,
&BpOff970,
&BpOff971,
&BpOff972,
&BpOff973,
&BpOff974,
&BpOff975,
&BpOff976,
&BpOff977,
&BpOff978,
&BpOff979,
&BpOff980,
&BpOff981,
&BpOff982,
&BpOff983,
&BpOff984,
&BpOff985,
&BpOff986,
&BpOff987,
&BpOff988,
&BpOff989,
&BpOff990,
&BpOff991,
&BpOff992,
&BpOff993,
&BpOff994,
&BpOff995,
&BpOff996,
&BpOff997,
&BpOff998,
&BpOff999,
&BpOff1000,
&BpOff1001,
&BpOff1002,
&BpOff1003,
&BpOff1004,
&BpOff1005,
&BpOff1006,
&BpOff1007,
&BpOff1008,
&BpOff1009,
&BpOff1010,
&BpOff1011,
&BpOff1012,
&BpOff1013,
&BpOff1014,
&BpOff1015,
&BpOff1016,
&BpOff1017,
&BpOff1018,
&BpOff1019,
&BpOff1020,
&BpOff1021,
&BpOff1022,
&BpOff1023,
&BpOff1024,
&BpOff1025,
&BpOff1026,
&BpOff1027,
&BpOff1028,
&BpOff1029,
&BpOff1030,
&BpOff1031,
&BpOff1032,
&BpOff1033,
&BpOff1034,
&BpOff1035,
&BpOff1036,
&BpOff1037,
&BpOff1038,
&BpOff1039,
&BpOff1040,
&BpOff1041,
&BpOff1042,
&BpOff1043,
&BpOff1044,
&BpOff1045,
&BpOff1046,
&BpOff1047,
&BpOff1048,
&BpOff1049,
&BpOff1050,
&BpOff1051,
&BpOff1052,
&BpOff1053,
&BpOff1054,
&BpOff1055,
&BpOff1056,
&BpOff1057,
&BpOff1058,
&BpOff1059,
&BpOff1060,
&BpOff1061,
&BpOff1062,
&BpOff1063,
&BpOff1064,
&BpOff1065,
&BpOff1066,
&BpOff1067,
&BpOff1068,
&BpOff1069,
&BpOff1070,
&BpOff1071,
&BpOff1072,
&BpOff1073,
&BpOff1074,
&BpOff1075,
&BpOff1076,
&BpOff1077,
&BpOff1078,
&BpOff1079,
&BpOff1080,
&BpOff1081,
&BpOff1082,
&BpOff1083,
&BpOff1084,
&BpOff1085,
&BpOff1086,
&BpOff1087,
&BpOff1088,
&BpOff1089,
&BpOff1090,
&BpOff1091,
&BpOff1092,
&BpOff1093,
&BpOff1094,
&BpOff1095,
&BpOff1096,
&BpOff1097,
&BpOff1098,
&BpOff1099,
&BpOff1100,
&BpOff1101,
&BpOff1102,
&BpOff1103,
&BpOff1104,
&BpOff1105,
&BpOff1106,
&BpOff1107,
&BpOff1108,
&BpOff1109,
&BpOff1110,
&BpOff1111,
&BpOff1112,
&BpOff1113,
&BpOff1114,
&BpOff1115,
&BpOff1116,
&BpOff1117,
&BpOff1118,
&BpOff1119,
&BpOff1120,
&BpOff1121,
&BpOff1122,
&BpOff1123,
&BpOff1124,
&BpOff1125,
&BpOff1126,
&BpOff1127,
&BpOff1128,
&BpOff1129,
&BpOff1130,
&BpOff1131,
&BpOff1132,
&BpOff1133,
&BpOff1134,
&BpOff1135,
&BpOff1136,
&BpOff1137,
&BpOff1138,
&BpOff1139,
&BpOff1140,
&BpOff1141,
&BpOff1142,
&BpOff1143,
&BpOff1144,
&BpOff1145,
&BpOff1146,
&BpOff1147,
&BpOff1148,
&BpOff1149,
&BpOff1150,
&BpOff1151,
&BpOff1152,
&BpOff1153,
&BpOff1154,
&BpOff1155,
&BpOff1156,
&BpOff1157,
&BpOff1158,
&BpOff1159,
&BpOff1160,
&BpOff1161,
&BpOff1162,
&BpOff1163,
&BpOff1164,
&BpOff1165,
&BpOff1166,
&BpOff1167,
&BpOff1168,
&BpOff1169,
&BpOff1170,
&BpOff1171,
&BpOff1172,
&BpOff1173,
&BpOff1174,
&BpOff1175,
&BpOff1176,
&BpOff1177,
&BpOff1178,
&BpOff1179,
&BpOff1180,
&BpOff1181,
&BpOff1182,
&BpOff1183,
&BpOff1184,
&BpOff1185,
&BpOff1186,
&BpOff1187,
&BpOff1188,
&BpOff1189,
&BpOff1190,
&BpOff1191,
&BpOff1192,
&BpOff1193,
&BpOff1194,
&BpOff1195,
&BpOff1196,
&BpOff1197,
&BpOff1198,
&BpOff1199,
&BpOff1200,
&BpOff1201,
&BpOff1202,
&BpOff1203,
&BpOff1204,
&BpOff1205,
&BpOff1206,
&BpOff1207,
&BpOff1208,
&BpOff1209,
&BpOff1210,
&BpOff1211,
&BpOff1212,
&BpOff1213,
&BpOff1214,
&BpOff1215,
&BpOff1216,
&BpOff1217,
&BpOff1218,
&BpOff1219,
&BpOff1220,
&BpOff1221,
&BpOff1222,
&BpOff1223,
&BpOff1224,
&BpOff1225,
&BpOff1226,
&BpOff1227,
&BpOff1228,
&BpOff1229,
&BpOff1230,
&BpOff1231,
&BpOff1232,
&BpOff1233,
&BpOff1234,
&BpOff1235,
&BpOff1236,
&BpOff1237,
&BpOff1238,
&BpOff1239,
&BpOff1240,
&BpOff1241,
&BpOff1242,
&BpOff1243,
&BpOff1244,
&BpOff1245,
&BpOff1246,
&BpOff1247,
&BpOff1248,
&BpOff1249,
&BpOff1250,
&BpOff1251,
&BpOff1252,
&BpOff1253,
&BpOff1254,
&BpOff1255,
&BpOff1256,
&BpOff1257,
&BpOff1258,
&BpOff1259,
&BpOff1260,
&BpOff1261,
&BpOff1262,
&BpOff1263,
&BpOff1264,
&BpOff1265,
&BpOff1266,
&BpOff1267,
&BpOff1268,
&BpOff1269,
&BpOff1270,
&BpOff1271,
&BpOff1272,
&BpOff1273,
&BpOff1274,
&BpOff1275,
&BpOff1276,
&BpOff1277,
&BpOff1278,
&BpOff1279,
&BpOff1280,
&BpOff1281,
&BpOff1282,
&BpOff1283,
&BpOff1284,
&BpOff1285,
&BpOff1286,
&BpOff1287,
&BpOff1288,
&BpOff1289,
&BpOff1290,
&BpOff1291,
&BpOff1292,
&BpOff1293,
&BpOff1294,
&BpOff1295,
&BpOff1296,
&BpOff1297,
&BpOff1298,
&BpOff1299,
&BpOff1300,
&BpOff1301,
&BpOff1302,
&BpOff1303,
&BpOff1304,
&BpOff1305,
&BpOff1306,
&BpOff1307,
&BpOff1308,
&BpOff1309,
&BpOff1310,
&BpOff1311,
&BpOff1312,
&BpOff1313,
&BpOff1314,
&BpOff1315,
&BpOff1316,
&BpOff1317,
&BpOff1318,
&BpOff1319,
&BpOff1320,
&BpOff1321,
&BpOff1322,
&BpOff1323,
&BpOff1324,
&BpOff1325,
&BpOff1326,
&BpOff1327,
&BpOff1328,
&BpOff1329,
&BpOff1330,
&BpOff1331,
&BpOff1332,
&BpOff1333,
&BpOff1334,
&BpOff1335,
&BpOff1336,
&BpOff1337,
&BpOff1338,
&BpOff1339,
&BpOff1340,
&BpOff1341,
&BpOff1342,
&BpOff1343,
&BpOff1344,
&BpOff1345,
&BpOff1346,
&BpOff1347,
&BpOff1348,
&BpOff1349,
&BpOff1350,
&BpOff1351,
&BpOff1352,
&BpOff1353,
&BpOff1354,
&BpOff1355,
&BpOff1356,
&BpOff1357,
&BpOff1358,
&BpOff1359,
&BpOff1360,
&BpOff1361,
&BpOff1362,
&BpOff1363,
&BpOff1364,
&BpOff1365,
&BpOff1366,
&BpOff1367,
&BpOff1368,
&BpOff1369,
    &InstantExpOffset,
    &AdmEspOffset,
    &NoEnemyAnimOffset1,
    &NoEnemyAnimOffset2,
    &RpgOffOffset,
    &DrinkWaterOffset,
    &SetVelocityOffset,
    &GetVelocityOffset,
    &SetIsKinematicOffset,
    &SetGroundedOffset,
    &SetDetectCollisionsOffset,
    &GetPositionOffset,
    &GetForwardOffset,
    &GetTransformOffset,
    &CameraOffset,
    &W2WPOffset,
    &IsAliveObjectOffset,
    &SetPositionOffset,
};



    NSString *filePath = [NSHomeDirectory() stringByAppendingPathComponent:NSENC("Documents/output.txt")];
    NSFileManager *fileManager = [NSFileManager defaultManager];
    
    if ([fileManager fileExistsAtPath:filePath]) {
        [fileManager removeItemAtPath:filePath error:nil];
    }
    
    NSFileHandle *fileHandle = [NSFileHandle fileHandleForWritingAtPath:filePath];
    if (!fileHandle) {
        [[NSFileManager defaultManager] createFileAtPath:filePath contents:nil attributes:nil];
        fileHandle = [NSFileHandle fileHandleForWritingAtPath:filePath];
    }

    for (size_t i = 0; i < vars.size(); i++) {
        NSString *line = [NSString stringWithFormat:NSENC("0x%llx\n"), *vars[i]];
        [fileHandle writeData:[line dataUsingEncoding:NSUTF8StringEncoding]];    

    }
    [fileHandle closeFile];
    
    NSLog(NSENC("Данные записаны в файл: %@"), filePath);
}




void OpenURL(NSString *urlString) {
    NSURL *url = [NSURL URLWithString:urlString];
    if ([[UIApplication sharedApplication] canOpenURL:url]) {
        [[UIApplication sharedApplication] openURL:url options:@{} completionHandler:^(BOOL success) {
            if (success) {
                NSLog(NSENC("Ссылка открыта успешно."));
            } else {
                NSLog(NSENC("Не удалось открыть ссылку."));
            }
        }];
    } else {
        NSLog(NSENC("Невозможно открыть ссылку: %@"), urlString);
    }
}
 



- (void)Flying{
    UIWindow *Window = [[[UIApplication sharedApplication] delegate] window];
    UP = [[UIButton alloc] initWithFrame:CGRectMake(sliderX, sliderY, 40, 40)];
    UP.layer.cornerRadius = 10.0;
    [UP setTitle:NSENC("UP") forState:UIControlStateNormal];
    [UP setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    UP.backgroundColor = [UIColor colorWithRed:34/255.0 green:181/255.0 blue:115/250.0 alpha:1];
    UP.layer.borderWidth = 0;
    [UP.titleLabel setFont:[UIFont systemFontOfSize:17]];
    [UP addTarget:self action:@selector(sheng) forControlEvents:UIControlEventTouchUpInside];
    [Window addSubview:UP];

    LOCK = [[UIButton alloc] initWithFrame:CGRectMake(sliderX, sliderY + 45, 40, 40)];
    LOCK.layer.cornerRadius = 10.0;//2.0是圆角的弧度，根据需求自己更改
    [LOCK setTitle:NSENC("LOCK") forState:UIControlStateNormal];
    [LOCK setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];//p1颜色
    LOCK.backgroundColor = [UIColor colorWithRed:255/255.0 green:0/255.0 blue:0/250.0 alpha:1];
    LOCK.layer.borderWidth = 0;//边框大小
    [LOCK.titleLabel setFont:[UIFont systemFontOfSize:10]];//字体大小
    [LOCK addTarget:self action:@selector(suo) forControlEvents:UIControlEventTouchUpInside];
    [Window addSubview:LOCK];
    
    DOWN = [[UIButton alloc] initWithFrame:CGRectMake(sliderX, sliderY + 90, 40, 40)];
    DOWN.layer.cornerRadius = 10.0;//2.0是圆角的弧度，根据需求自己更改
    [DOWN setTitle:NSENC("DOWN") forState:UIControlStateNormal];
    [DOWN setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];//p1颜色
    DOWN.backgroundColor = [UIColor colorWithRed:34/255.0 green:181/255.0 blue:115/250.0 alpha:1];
    DOWN.layer.borderWidth = 0;//边框大小
    [DOWN.titleLabel setFont:[UIFont systemFontOfSize:10]];//字体大小
    [DOWN addTarget:self action:@selector(jiang) forControlEvents:UIControlEventTouchUpInside];
    [Window addSubview:DOWN];

    SOUL = [[UIButton alloc] initWithFrame:CGRectMake(sliderX, sliderY + 135, 40, 40)];
    SOUL.layer.cornerRadius = 10.0;//2.0是圆角的弧度，根据需求自己更改
    [SOUL setTitle:NSENC("SOUL") forState:UIControlStateNormal];
    [SOUL setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];//p1颜色
    SOUL.backgroundColor = [UIColor colorWithRed:255/255.0 green:0/255.0 blue:0/250.0 alpha:1];
    SOUL.layer.borderWidth = 0;//边框大小
    [SOUL.titleLabel setFont:[UIFont systemFontOfSize:10]];//字体大小
    [SOUL addTarget:self action:@selector(soulb) forControlEvents:UIControlEventTouchUpInside];
    [Window addSubview:SOUL];

    NOCLIP = [[UIButton alloc] initWithFrame:CGRectMake(sliderX, sliderY + 180, 40, 40)];
    NOCLIP.layer.cornerRadius = 10.0;//2.0是圆角的弧度，根据需求自己更改
    [NOCLIP setTitle:NSENC("NOCLIP") forState:UIControlStateNormal];
    [NOCLIP setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];//p1颜色
    NOCLIP.backgroundColor = [UIColor colorWithRed:255/255.0 green:0/255.0 blue:0/250.0 alpha:1];
    NOCLIP.layer.borderWidth = 0;//边框大小
    [NOCLIP.titleLabel setFont:[UIFont systemFontOfSize:10]];//字体大小
    [NOCLIP addTarget:self action:@selector(noclipb) forControlEvents:UIControlEventTouchUpInside];
    [Window addSubview:NOCLIP];

}

- (void)updateButtonPositions {
    UP.frame = CGRectMake(sliderX, sliderY, 40, 40);
    LOCK.frame = CGRectMake(sliderX, sliderY + 45, 40, 40);
    DOWN.frame = CGRectMake(sliderX, sliderY + 90, 40, 40);
    SOUL.frame = CGRectMake(sliderX, sliderY + 135, 40, 40);
    NOCLIP.frame = CGRectMake(sliderX, sliderY + 180, 40, 40);
}

- (void)updateButtonColors {
    UP.backgroundColor = [UIColor colorWithRed:34/255.0 green:181/255.0 blue:115/250.0 alpha:1];
    DOWN.backgroundColor = [UIColor colorWithRed:34/255.0 green:181/255.0 blue:115/250.0 alpha:1];
    if(soul){
    SOUL.backgroundColor = [UIColor colorWithRed:34/255.0 green:181/255.0 blue:115/250.0 alpha:1];
    }else{
    SOUL.backgroundColor = [UIColor colorWithRed:255/255.0 green:0/255.0 blue:0/250.0 alpha:1];
    }
    
    if(noclip){
    NOCLIP.backgroundColor = [UIColor colorWithRed:34/255.0 green:181/255.0 blue:115/250.0 alpha:1];
    }else{
    NOCLIP.backgroundColor = [UIColor colorWithRed:255/255.0 green:0/255.0 blue:0/250.0 alpha:1];
    }
    
    if(Plock){
    LOCK.backgroundColor = [UIColor colorWithRed:34/255.0 green:181/255.0 blue:115/250.0 alpha:1];
    }else{
    LOCK.backgroundColor = [UIColor colorWithRed:255/255.0 green:0/255.0 blue:0/250.0 alpha:1];
    }

}

- (void)sheng{
    [self modifyLocalPlayerPosX:0 y:1 z:0];
}
- (void)jiang{
    [self modifyLocalPlayerPosX:0 y:-1 z:0];
}
- (void)suo{
    Plock =! Plock;

    if(isJb == 0){
        if(Plock){
            vm_unity32(GetVelocityOffset, strtoul(ENCRYPT("C0035FD6"), nullptr, 0));
        }else{
            vm_unity32(GetVelocityOffset, strtoul(ENCRYPT("0x44ADE98"), nullptr, 0));
        }

    }else{
        if(Plock){
            ActiveCodePatch(UnityFramework, GetVelocityOffset, "C0035FD6");
        }else{
            DeactiveCodePatch(UnityFramework, GetVelocityOffset, "C0035FD6");
        }
    }


    [self updateButtonColors];
}
- (void)soulb{
    soul =! soul;
    offsetFunc();
    [self updateButtonColors];
}
- (void)noclipb{
   noclip =! noclip;
   if(noclip){
      HexIpa->set_detectCollisions(me->rigid, false);
//vm_unity32(ENCRYPTOFFSET("0x12FDEB0"), strtoul(ENCRYPTHEX("0xC0035FD6"), nullptr, 0));
   }else{
      HexIpa->set_detectCollisions(me->rigid, true);
   }
   [self updateButtonColors];
}

- (void)modifyLocalPlayerPosX:(float)x y:(float)y z:(float)z
{
    void* playerTransform = me->trans;

    Vector3 position = me->pos;

    position.x += x * Xhit;
    position.y += y * FlyingHeight;
    position.z += z * MAX(FlyingHeight, 6);
    
    HexIpa->set_position(playerTransform, position);
}


- (void)mtkView:(MTKView*)view drawableSizeWillChange:(CGSize)size
{
    
}


@end

